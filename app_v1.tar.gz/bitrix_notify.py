"""
bitrix_notify.py — отправка отчёта о рабочем времени в групповой чат Битрикс24.
Вызывается автоматически после POST /api/report/submit.
Лог пишется в bitrix_notify.log рядом с файлом.

Ручной запуск (отправить отчёт за сегодня по всем прорабам):
    python3 bitrix_notify.py
    python3 bitrix_notify.py --date 2025-07-10
"""

import httpx
import logging
import asyncio
import aiomysql
import os
import sys
import argparse
from datetime import datetime, date
from pathlib import Path
from bitrix_token import get_access_token

LOG_FILE = Path(os.path.dirname(os.path.abspath(__file__))) / "bitrix_notify.log"

logger = logging.getLogger("bitrix_notify")
logger.setLevel(logging.DEBUG)

_fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
_fh.setLevel(logging.DEBUG)
_fh.setFormatter(logging.Formatter(
    "%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
))

_ch = logging.StreamHandler(sys.stdout)
_ch.setLevel(logging.INFO)
_ch.setFormatter(logging.Formatter(
    "%(asctime)s  %(levelname)s  %(message)s",
    datefmt="%H:%M:%S",
))

logger.addHandler(_fh)
logger.addHandler(_ch)


DOMAIN  = os.getenv("BX_DOMAIN",  "")
CHAT_ID = os.getenv("BX_CHAT_ID", "")

DB_CONFIG = {
    "host":       os.getenv("DB_HOST",     ""),
    "port":       int(os.getenv("DB_PORT", "3306")),
    "user":       os.getenv("DB_USER",     ""),
    "password":   os.getenv("DB_PASSWORD", ""),
    "db":         os.getenv("DB_NAME",     ""),
    "charset":    "utf8mb4",
    "autocommit": True,
}
FLAT = os.getenv("DB_TABLE", "worktime_flat")


def _fmt_time(iso) -> str:
    if not iso:
        return "—"
    try:
        return datetime.fromisoformat(str(iso)).strftime("%H:%M")
    except Exception:
        return str(iso)


def _fmt_hours(minutes: int) -> str:
    if not minutes:
        return "0м"
    h, m = divmod(minutes, 60)
    return f"{h}ч {m}м" if h else f"{m}м"


def build_message(report_date: str, foreman_name: str, entries: list) -> str:
    lines = []
    lines.append("📋 [B]Отчёт о рабочем времени[/B]")
    lines.append(f"📅 Дата: [B]{report_date}[/B]")
    lines.append(f"👷 Прораб: [B]{foreman_name}[/B]")
    lines.append("")
    lines.append("[B]Сотрудники:[/B]")

    total_all_minutes = 0
    for e in entries:
        name  = e.get("user_name", "—")
        start = _fmt_time(e.get("adjusted_start"))
        end   = _fmt_time(e.get("adjusted_end"))
        lunch = e.get("lunch_minutes", 0)
        total = e.get("total_minutes", 0) or 0
        total_all_minutes += total

        lunch_str = f"обед {lunch}м  |  " if lunch else ""
        lines.append(
            f"  • [B]{name}[/B]: {start} – {end}  |  {lunch_str}итого [B]{_fmt_hours(total)}[/B]"
        )

    lines.append("")
    lines.append(f"⏱ [B]Итого по всем:[/B] {_fmt_hours(total_all_minutes)}")
    lines.append("✅ Отчёт подтверждён")
    return "\n".join(lines)


async def send_report_to_chat(
    report_date: str,
    foreman_name: str,
    entries: list,
    chat_id: str = CHAT_ID,
) -> bool:
    logger.info(f"Отправка отчёта в чат {chat_id}: дата={report_date}, прораб={foreman_name}, сотрудников={len(entries)}")

    try:
        token   = await get_access_token()
        message = build_message(report_date, foreman_name, entries)

        url = f"https://{DOMAIN}/rest/im.message.add"
        payload = {
            "auth":      token,
            "DIALOG_ID": f"chat{chat_id}",
            "MESSAGE":   message,
        }

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(url, json=payload)

        result = resp.json()

        if result.get("result"):
            logger.info(f"Сообщение отправлено, msg_id={result['result']}")
            return True
        else:
            error      = result.get("error", "неизвестно")
            error_desc = result.get("error_description", "")
            logger.error(f"Ошибка API Битрикс24: error={error}, description={error_desc}")
            return False

    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP ошибка: {e.response.status_code} — {e.response.text[:300]}")
        return False
    except Exception as exc:
        logger.exception(f"Неожиданное исключение при отправке: {exc}")
        return False


async def _fetch_reports(report_date: date) -> dict:
    """Возвращает dict: foreman_id -> {foreman_name, entries}.
    Только подтверждённые записи (confirmed_at IS NOT NULL)."""
    pool = await aiomysql.create_pool(**DB_CONFIG)
    try:
        async with pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(
                    f"""
                    SELECT
                        foreman_id, foreman_name,
                        user_name,
                        adjusted_start, adjusted_end,
                        lunch_minutes, total_minutes
                    FROM `{FLAT}`
                    WHERE report_date = %s
                      AND confirmed_at IS NOT NULL
                    ORDER BY foreman_id, user_name
                    """,
                    (report_date,),
                )
                rows = await cur.fetchall()
    finally:
        pool.close()
        await pool.wait_closed()

    reports: dict = {}
    for r in rows:
        fid = r["foreman_id"]
        if fid not in reports:
            reports[fid] = {
                "foreman_name": r["foreman_name"],
                "entries":      [],
            }
        reports[fid]["entries"].append({
            "user_name":      r["user_name"],
            "adjusted_start": r["adjusted_start"].isoformat() if r["adjusted_start"] else None,
            "adjusted_end":   r["adjusted_end"].isoformat()   if r["adjusted_end"]   else None,
            "lunch_minutes":  r["lunch_minutes"],
            "total_minutes":  r["total_minutes"],
        })

    return reports


async def manual_run(report_date: date):
    logger.info(f"Ручной запуск за дату: {report_date}")

    reports = await _fetch_reports(report_date)

    if not reports:
        logger.warning(f"Нет подтверждённых отчётов за {report_date}")
        return

    logger.info(f"Найдено прорабов с отчётами: {len(reports)}")

    for foreman_id, data in reports.items():
        ok = await send_report_to_chat(
            report_date=report_date.isoformat(),
            foreman_name=data["foreman_name"],
            entries=data["entries"],
        )
        status = "отправлен" if ok else "ошибка отправки"
        logger.info(f"Прораб {data['foreman_name']} (id={foreman_id}): {status}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Ручная отправка отчётов за дату в Битрикс24-чат"
    )
    parser.add_argument(
        "--date", "-d",
        default=date.today().isoformat(),
        help="Дата отчёта YYYY-MM-DD (по умолчанию сегодня)",
    )
    args = parser.parse_args()

    try:
        target_date = date.fromisoformat(args.date)
    except ValueError:
        sys.stderr.write(f"Неверный формат даты: {args.date}. Используйте YYYY-MM-DD\n")
        sys.exit(1)

    asyncio.run(manual_run(target_date))
