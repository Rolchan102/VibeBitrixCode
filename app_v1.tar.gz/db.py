import os
from dotenv import load_dotenv
load_dotenv("/opt/mordason-worktime/.env")

import aiomysql
from contextlib import asynccontextmanager

_pool = None


def _get_config():
    return {
        "host":       os.getenv("DB_HOST",     ""),
        "port":       int(os.getenv("DB_PORT", "3306")),
        "user":       os.getenv("DB_USER",     ""),
        "password":   os.getenv("DB_PASSWORD", ""),
        "db":         os.getenv("DB_NAME",     ""),
        "charset":    "utf8mb4",
        "autocommit": True,
    }


async def get_pool():
    global _pool
    if _pool is None:
        _pool = await aiomysql.create_pool(**_get_config())
    return _pool


@asynccontextmanager
async def get_conn():
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            yield conn, cur
