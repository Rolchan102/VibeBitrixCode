import logging
import asyncio
import os
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime
from db import get_conn
from bitrix_notify import send_report_to_chat

router = APIRouter(prefix="/api/report", tags=["report"])

logger = logging.getLogger(__name__)

FLAT        = os.getenv("DB_TABLE", "worktime_flat")
SYNC_SCRIPT = os.path.join(os.path.dirname(__file__), "sync_to_sheets.py")


class EntryIn(BaseModel):
    user_id:        str
    user_name:      str = ""
    raw_start:      Optional[str] = None
    raw_end:        Optional[str] = None
    adjusted_start: str
    adjusted_end:   str
    lunch_minutes:  int = 0


class ReportIn(BaseModel):
    foreman_id:   str
    foreman_name: str = ""
    entries:      List[EntryIn]


def parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None


def calc_total(adj_start: datetime, adj_end: datetime, lunch_minutes: int) -> int:
    delta = int((adj_end - adj_start).total_seconds() // 60)
    return max(0, delta - lunch_minutes)


async def _sync_bg():
    try:
        proc = await asyncio.create_subprocess_exec(
            "python3", SYNC_SCRIPT,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logger.error(f"sync_to_sheets error: {stderr.decode()}")
        else:
            logger.info(f"sync_to_sheets ok: {stdout.decode().strip()}")
    except Exception as e:
        logger.exception(f"sync_to_sheets exception: {e}")


async def _notify_bg(report_date: str, foreman_name: str, entries: list):
    await send_report_to_chat(
        report_date=report_date,
        foreman_name=foreman_name,
        entries=entries,
    )


@router.get("/status")
async def report_status(foreman_id: str, report_date: Optional[str] = None):
    rdate = date.fromisoformat(report_date) if report_date else date.today()
    async with get_conn() as (conn, cur):
        await cur.execute(
            f"""
            SELECT MIN(confirmed_at) AS submitted_at
            FROM `{FLAT}`
            WHERE foreman_id=%s AND report_date=%s AND confirmed_at IS NOT NULL
            """,
            (foreman_id, rdate),
        )
        row = await cur.fetchone()

    if row and row["submitted_at"]:
        return {"submitted": True, "submitted_at": row["submitted_at"].isoformat()}
    return {"submitted": False}


@router.get("/view")
async def report_view(foreman_id: str, report_date: Optional[str] = None):
    rdate = date.fromisoformat(report_date) if report_date else date.today()
    async with get_conn() as (conn, cur):
        await cur.execute(
            f"SELECT * FROM `{FLAT}` WHERE foreman_id=%s AND report_date=%s ORDER BY user_name",
            (foreman_id, rdate),
        )
        rows = await cur.fetchall()

    if not rows:
        raise HTTPException(404, "Отчёт не найден")

    first = rows[0]

    def fmt(r):
        return {
            "user_id":        r["user_id"],
            "user_name":      r["user_name"],
            "raw_start":      r["raw_start"].isoformat()      if r["raw_start"]      else None,
            "raw_end":        r["raw_end"].isoformat()        if r["raw_end"]        else None,
            "adjusted_start": r["adjusted_start"].isoformat(),
            "adjusted_end":   r["adjusted_end"].isoformat(),
            "lunch_minutes":  r["lunch_minutes"],
            "total_minutes":  r["total_minutes"],
        }

    return {
        "foreman_id":   first["foreman_id"],
        "foreman_name": first["foreman_name"],
        "report_date":  first["report_date"].isoformat(),
        "submitted_at": first["confirmed_at"].isoformat(),
        "entries":      [fmt(r) for r in rows],
    }


@router.post("/submit")
async def report_submit(body: ReportIn):
    rdate        = date.today()
    confirmed_at = datetime.now()

    async with get_conn() as (conn, cur):
        await cur.execute(
            f"SELECT COUNT(*) AS cnt FROM `{FLAT}` WHERE foreman_id=%s AND report_date=%s AND confirmed_at IS NOT NULL",
            (body.foreman_id, rdate),
        )
        if (await cur.fetchone())["cnt"] > 0:
            raise HTTPException(409, "Отчёт за сегодня уже отправлен и заблокирован")

        saved_entries = []
        entries_count = 0

        for e in body.entries:
            adj_s = parse_dt(e.adjusted_start)
            adj_e = parse_dt(e.adjusted_end)

            if not adj_s or not adj_e:
                raise HTTPException(400, f"Некорректное время для {e.user_id}")
            if adj_e <= adj_s:
                raise HTTPException(400, f"Конец раньше начала для {e.user_id}")

            total = calc_total(adj_s, adj_e, e.lunch_minutes)

            await cur.execute(
                f"SELECT id FROM `{FLAT}` WHERE user_id=%s AND report_date=%s AND confirmed_at IS NULL LIMIT 1",
                (e.user_id, rdate),
            )
            row = await cur.fetchone()

            if row:
                await cur.execute(
                    f"""
                    UPDATE `{FLAT}` SET
                        adjusted_start=%s, adjusted_end=%s,
                        lunch_minutes=%s, total_minutes=%s,
                        foreman_id=%s, foreman_name=%s, confirmed_at=%s
                    WHERE id=%s
                    """,
                    (adj_s, adj_e, e.lunch_minutes, total,
                     body.foreman_id, body.foreman_name, confirmed_at, row["id"]),
                )
            else:
                await cur.execute(
                    f"""
                    INSERT INTO `{FLAT}`
                        (user_id, user_name, raw_start, raw_end,
                         adjusted_start, adjusted_end, lunch_minutes, total_minutes,
                         foreman_id, foreman_name, confirmed_at, report_date)
                    VALUES (%s,%s,NULL,NULL,%s,%s,%s,%s,%s,%s,%s,%s)
                    """,
                    (e.user_id, e.user_name, adj_s, adj_e,
                     e.lunch_minutes, total,
                     body.foreman_id, body.foreman_name, confirmed_at, rdate),
                )

            saved_entries.append({
                "user_name":      e.user_name,
                "adjusted_start": e.adjusted_start,
                "adjusted_end":   e.adjusted_end,
                "lunch_minutes":  e.lunch_minutes,
                "total_minutes":  total,
            })
            entries_count += 1

    asyncio.create_task(_sync_bg())
    asyncio.create_task(_notify_bg(
        report_date=rdate.isoformat(),
        foreman_name=body.foreman_name,
        entries=saved_entries,
    ))

    return {"ok": True, "entries_count": entries_count}
