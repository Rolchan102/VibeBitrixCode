import logging
import asyncio
import json
import os
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import date, datetime
from db import get_conn

router = APIRouter(prefix="/api/workday", tags=["workday"])

logger = logging.getLogger(__name__)

LOG_PATH    = os.path.join(os.path.dirname(__file__), "workday_log.json")
SYNC_SCRIPT = os.path.join(os.path.dirname(__file__), "sync_to_sheets.py")
FLAT        = os.getenv("DB_TABLE", "worktime_flat")
_lock       = asyncio.Lock()


def _read_log() -> list:
    if not os.path.exists(LOG_PATH):
        return []
    try:
        with open(LOG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _write_log(entries: list):
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def _today_str() -> str:
    return date.today().isoformat()


async def _sync_bg():
    try:
        proc = await asyncio.create_subprocess_exec(
            "python3", SYNC_SCRIPT,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logger.error(f"sync_to_sheets error: {stderr.decode()}")
        else:
            logger.info(f"sync_to_sheets ok: {stdout.decode().strip()}")
    except Exception as e:
        logger.exception(f"sync_to_sheets exception: {e}")


class ActionIn(BaseModel):
    user_id:   str
    user_name: str = ""


@router.get("/status")
async def get_status(user_id: str):
    today = _today_str()
    async with _lock:
        entries = _read_log()

    user_today = sorted(
        [e for e in entries if e["user_id"] == user_id and e["date"] == today],
        key=lambda x: x["ts"], reverse=True,
    )

    if not user_today:
        return {"status": "not_started", "start": None, "stop": None}

    start_ts = next((e["ts"] for e in user_today if e["action"] == "start"), None)
    stop_ts  = next((e["ts"] for e in user_today if e["action"] == "stop"),  None)
    return {"status": user_today[0]["action"], "start": start_ts, "stop": stop_ts}


@router.post("/start")
async def workday_start(body: ActionIn):
    today = _today_str()
    now   = datetime.now().isoformat(timespec="seconds")

    async with _lock:
        entries    = _read_log()
        user_today = sorted(
            [e for e in entries if e["user_id"] == body.user_id and e["date"] == today],
            key=lambda x: x["ts"], reverse=True,
        )
        if user_today and user_today[0]["action"] == "start":
            raise HTTPException(400, "День уже начат")

        entries.append({"user_id": body.user_id, "user_name": body.user_name,
                        "action": "start", "date": today, "ts": now})
        _write_log(entries)

    return {"ok": True, "action": "start", "ts": now}


@router.post("/stop")
async def workday_stop(body: ActionIn):
    today      = _today_str()
    now        = datetime.now().isoformat(timespec="seconds")
    today_date = date.today()

    async with _lock:
        entries    = _read_log()
        user_today = sorted(
            [e for e in entries if e["user_id"] == body.user_id and e["date"] == today],
            key=lambda x: x["ts"], reverse=True,
        )
        if not user_today or user_today[0]["action"] != "start":
            raise HTTPException(400, "День не был начат")

        start_ts = next((e["ts"] for e in user_today if e["action"] == "start"), None)

        entries.append({"user_id": body.user_id, "user_name": body.user_name,
                        "action": "stop", "date": today, "ts": now})
        _write_log(entries)

    raw_start_dt = datetime.fromisoformat(start_ts) if start_ts else None
    raw_stop_dt  = datetime.fromisoformat(now)

    async with get_conn() as (conn, cur):
        await cur.execute(
            f"SELECT id FROM `{FLAT}` WHERE user_id=%s AND report_date=%s LIMIT 1",
            (body.user_id, today_date),
        )
        existing = await cur.fetchone()

        if existing:
            await cur.execute(
                f"UPDATE `{FLAT}` SET raw_start=%s, raw_end=%s, user_name=%s WHERE id=%s",
                (raw_start_dt, raw_stop_dt, body.user_name, existing["id"]),
            )
        else:
            await cur.execute(
                f"""
                INSERT INTO `{FLAT}`
                    (user_id, user_name, raw_start, raw_end,
                     adjusted_start, adjusted_end,
                     lunch_minutes, total_minutes,
                     foreman_id, foreman_name, confirmed_at, report_date)
                VALUES (%s,%s,%s,%s,%s,%s,0,0,'','',NULL,%s)
                """,
                (body.user_id, body.user_name,
                 raw_start_dt, raw_stop_dt,
                 raw_start_dt, raw_stop_dt,
                 today_date),
            )

    asyncio.create_task(_sync_bg())

    return {"ok": True, "action": "stop", "ts": now}


@router.get("/today")
async def get_today_log():
    today = _today_str()
    async with _lock:
        entries = _read_log()

    users: dict = {}
    for e in [x for x in entries if x["date"] == today]:
        uid = e["user_id"]
        if uid not in users:
            users[uid] = {"user_id": uid, "user_name": e["user_name"], "start": None, "stop": None}
        if e["action"] == "start" and users[uid]["start"] is None:
            users[uid]["start"] = e["ts"]
        if e["action"] == "stop":
            users[uid]["stop"] = e["ts"]

    return list(users.values())
