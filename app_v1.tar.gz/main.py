from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.workday import router as workday_router
from routes.reports import router as reports_router

app = FastAPI(title="Mordason Worktime API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Битрикс24 шлёт с разных доменов
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(workday_router)
app.include_router(reports_router)


@app.get("/")
async def root():
    return {"status": "ok", "service": "worktime-api"}
