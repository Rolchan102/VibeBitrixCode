"""
main.py — единое FastAPI-приложение v2.1 (итерация 2).

Стек: Python + FastAPI + MySQL (aiomysql).
Node.js убран полностью.

Два iframe в Битрикс24:
  /index.html   → public/index.html    (прораб: отчёт + выплаты своей бригады)
  /payroll.html → public/payroll.html  (бухгалтер/админ: все бригады, ставки)

Роутеры:
  /api/foreman/*  — отчёт прораба (подтверждение часов, уведомление в чат)
  /api/payroll/*  — учёт выплат (ставки, премии, месячный отчёт)
  /api/timeman/*  — прокси к Б24 timeman.status + крон 23:30 МСК
"""

import logging
import os
import json
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi import Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from routes.foreman import router as foreman_router
from routes.payroll import router as payroll_router
from routes.timeman import router as timeman_router, start_cron, stop_cron

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ── Lifespan ─────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Пул БД
    from db import get_pool
    await get_pool()
    logger.info("DB pool initialized")

    # Крон автосохранения часов
    start_cron()

    yield

    # Остановка
    stop_cron()

    from db import close_pool
    await close_pool()
    logger.info("DB pool closed")


# ── Приложение ───────────────────────────────────────────────
app = FastAPI(
    title="Mordason Worktime API",
    version="2.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# API роутеры — ПЕРЕД статикой
app.include_router(foreman_router)
app.include_router(payroll_router)
app.include_router(timeman_router)


# ── Диагностика ──────────────────────────────────────────────
@app.get("/api/ping")
async def ping():
    import datetime
    return {
        "ok":      True,
        "ts":      datetime.datetime.now().isoformat(),
        "version": "2.1.0",
    }


@app.get("/api/config/roles")
async def get_roles():
    """
    Возвращает FOREMAN_IDS и ADMIN_IDS из env.
    Фронтенд читает при инициализации чтобы определить режим UI.
    """
    foreman_ids = [x.strip() for x in os.getenv("FOREMAN_IDS", "").split(",") if x.strip()]
    admin_ids   = [x.strip() for x in os.getenv("ADMIN_IDS",   "").split(",") if x.strip()]
    return {"foreman_ids": foreman_ids, "admin_ids": admin_ids}


@app.get("/api/me")
async def get_me(request: Request):
    user_id   = request.headers.get("X-Vibe-User-Id", "")
    user_name = request.headers.get("X-Vibe-User-Name-Encoded", "")
    if user_name:
        from urllib.parse import unquote
        user_name = unquote(user_name)
    else:
        user_name = request.headers.get("X-Vibe-User-Name", "")
    return {"id": user_id, "name": user_name}
   
   
@app.post("/api/bx/install")
async def bx_install(request: Request):
    form = await request.form()
    tokens = {
        "access_token":  form.get("AUTH_ID", ""),
        "refresh_token": form.get("REFRESH_ID", ""),
        "domain":        form.get("DOMAIN", ""),
        "member_id":     form.get("member_id", ""),
        "installed_at":  __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    Path("tokens.json").write_text(
        json.dumps(tokens, ensure_ascii=False, indent=4),
        encoding="utf-8"
    )
    return HTMLResponse("<script>BX24.closeApplication();</script>")


# ── Статика — ПОСЛЕ /api/* ───────────────────────────────────
if os.path.isdir("public"):
    app.mount("/", StaticFiles(directory="public", html=True), name="static")
    logger.info("Static files mounted from ./public")
else:
    logger.warning("./public not found — static files not served")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", "3000")))
