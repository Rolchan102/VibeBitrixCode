"""
bitrix_token.py — менеджер токенов Битрикс24.
Читает tokens.json, при необходимости обновляет access_token через refresh_token.

Требует переменных окружения:
  BX_CLIENT_ID      — из настроек приложения в Битрикс24
  BX_CLIENT_SECRET  — из настроек приложения в Битрикс24
"""

import os
import json
import logging
import asyncio
from datetime import datetime
from pathlib import Path
import httpx
from dotenv import load_dotenv

BASE_DIR    = Path(os.path.dirname(__file__))
TOKENS_FILE = BASE_DIR / "tokens.json"
LOG_FILE    = BASE_DIR / "bitrix_bot.log"

load_dotenv(dotenv_path=BASE_DIR / ".env")

CLIENT_ID     = os.getenv("BX_CLIENT_ID",     "")
CLIENT_SECRET = os.getenv("BX_CLIENT_SECRET", "")

_lock = asyncio.Lock()


def _setup_logger() -> logging.Logger:
    log = logging.getLogger("bitrix")
    if log.handlers:
        return log

    log.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        "%(asctime)s  %(levelname)-8s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    log.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    log.addHandler(ch)

    return log


logger = _setup_logger()


def _load() -> dict:
    with open(TOKENS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data: dict):
    with open(TOKENS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


async def get_access_token() -> str:
    """Возвращает действующий access_token, при необходимости обновляет его."""
    async with _lock:
        data = _load()

        installed_at = datetime.fromisoformat(data.get("installed_at", "2000-01-01 00:00:00"))
        age_minutes  = (datetime.now() - installed_at).total_seconds() / 60

        if age_minutes < 55:
            logger.debug(f"Токен свежий (возраст {age_minutes:.1f} мин), обновление не нужно")
            return data["access_token"]

        logger.info(f"Токен устарел ({age_minutes:.1f} мин), запускаем refresh...")
        return await _refresh(data)


async def _refresh(data: dict) -> str:
    domain  = data["domain"]
    refresh = data["refresh_token"]

    url = "https://oauth.bitrix.info/oauth/token/"
    params = {
        "grant_type":    "refresh_token",
        "client_id":     CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "refresh_token": refresh,
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
            new = resp.json()
    except Exception as e:
        logger.error(f"Ошибка при refresh токена: {e}")
        raise

    if "access_token" not in new:
        logger.error(f"Битрикс24 не вернул access_token: {new}")
        raise RuntimeError(f"Bitrix24 refresh failed: {new}")

    updated = {
        "access_token":  new["access_token"],
        "refresh_token": new["refresh_token"],
        "domain":        domain,
        "member_id":     data.get("member_id", ""),
        "installed_at":  datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _save(updated)
    logger.info(f"Токен обновлён в {updated['installed_at']}")
    return updated["access_token"]
