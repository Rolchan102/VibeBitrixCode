-- ============================================================
-- Migration 001 — таблицы учёта выплат
-- Применять однократно на существующей БД
-- ============================================================

-- ------------------------------------------------------------
-- 1. payroll_rates
--    Ставка и премия сотрудника за конкретный месяц.
--    Если записи нет — используется дефолтная ставка из .env.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payroll_rates` (
    `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `employee_id`   VARCHAR(32)     NOT NULL COMMENT 'ID пользователя Битрикс24',
    `employee_name` VARCHAR(255)    NOT NULL DEFAULT '' COMMENT 'Имя — кэш, обновляется при изменении',
    `month`         CHAR(7)         NOT NULL COMMENT 'Формат YYYY-MM',
    `rate`          DECIMAL(10, 2)  NOT NULL DEFAULT 500.00 COMMENT 'Ставка за час, руб.',
    `bonus`         DECIMAL(10, 2)  NOT NULL DEFAULT 0.00   COMMENT 'Фиксированная премия за месяц, руб.',
    `updated_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `updated_by`    VARCHAR(255)    NOT NULL DEFAULT '' COMMENT 'Кто изменил (имя пользователя)',

    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_employee_month` (`employee_id`, `month`),
    KEY `idx_month` (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Ставки и премии сотрудников по месяцам';


-- ------------------------------------------------------------
-- 2. payroll_daily
--    Ежедневные часы из timeman.status.
--    Заполняется двумя путями:
--      a) автокрон 23:30 МСК (source = 'auto_cron')
--      b) прораб подтвердил отчёт (source = 'foreman_approved')
--    Запись прораба имеет приоритет и не перезаписывается кроном.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payroll_daily` (
    `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `employee_id`   VARCHAR(32)     NOT NULL COMMENT 'ID пользователя Битрикс24',
    `employee_name` VARCHAR(255)    NOT NULL DEFAULT '',
    `report_date`   DATE            NOT NULL,
    `hours`         DECIMAL(6, 2)   NOT NULL DEFAULT 0.00 COMMENT 'Итоговые часы (уже за вычетом обеда)',
    `duration_sec`  INT UNSIGNED    NOT NULL DEFAULT 0    COMMENT 'Raw длительность из timeman, секунды',
    `b24_status`    VARCHAR(32)     NOT NULL DEFAULT ''   COMMENT 'STATUS из timeman: OPENED/CLOSED/...',
    `source`        ENUM(
                        'auto_cron',        -- записал крон 23:30
                        'foreman_approved', -- подтвердил прораб
                        'manual_override'   -- ручная правка через payroll-интерфейс
                    ) NOT NULL DEFAULT 'auto_cron',
    `approved_by`   VARCHAR(255)    NOT NULL DEFAULT '' COMMENT 'Имя прораба при foreman_approved',
    `approved_by_id` VARCHAR(32)    NOT NULL DEFAULT '' COMMENT 'ID прораба',
    `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_employee_date` (`employee_id`, `report_date`),
    KEY `idx_date`          (`report_date`),
    KEY `idx_employee_date` (`employee_id`, `report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Ежедневные часы сотрудников (замена hours_*.json)';


-- ------------------------------------------------------------
-- 3. Справка: существующая worktime_flat (не меняем)
--    Используется для отчётов прораба (подтверждение смен).
--    payroll_daily читает из неё данные при foreman_approved.
-- ------------------------------------------------------------
-- CREATE TABLE `worktime_flat` (
--     `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
--     `user_id`       VARCHAR(32)  NOT NULL,
--     `user_name`     VARCHAR(255) NOT NULL DEFAULT '',
--     `raw_start`     DATETIME     DEFAULT NULL,
--     `raw_end`       DATETIME     DEFAULT NULL,
--     `adjusted_start` DATETIME   NOT NULL,
--     `adjusted_end`  DATETIME    NOT NULL,
--     `lunch_minutes` SMALLINT    NOT NULL DEFAULT 0,
--     `total_minutes` SMALLINT    NOT NULL DEFAULT 0,
--     `foreman_id`    VARCHAR(32)  NOT NULL DEFAULT '',
--     `foreman_name`  VARCHAR(255) NOT NULL DEFAULT '',
--     `confirmed_at`  DATETIME     DEFAULT NULL,
--     `report_date`   DATE         NOT NULL,
--     PRIMARY KEY (`id`),
--     KEY `idx_foreman_date` (`foreman_id`, `report_date`),
--     KEY `idx_user_date`    (`user_id`,    `report_date`)
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
