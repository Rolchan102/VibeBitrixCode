"""
timeman.py — прокси к Б24 timeman.status + крон автосохранения часов.

Эндпоинты:
  GET /api/timeman/team-status?user_ids=1,2,3
      Опрашивает timeman.status для списка сотрудников через вебхук.
      Используется фронтендом прораба при переходе к шагу редактирования.

  GET /api/timeman/users
      Список всех активных сотрудников Б24 (user.get).
      Кэшируется в памяти на 10 минут чтобы не долбить Б24 при каждом открытии.

  POST /api/timeman/cron/run
      Ручной запуск крона (для отладки, только с ?secret=...).

Крон:
  Каждый день в CRON_DAILY_SAVE_TIME (по умолчанию 23:30 МСК) опрашивает
  timeman.status для всех активных сотрудников и пишет в payroll_daily
  со статусом 'auto_cron'. Записи с источником 'foreman_approved' и
  'manual_override' не перезаписываются.

Аутентификация к Б24:
  Используется вебхук BX_WEBHOOK (не OAuth-токен) — проще для крона,
  не требует рефреша. Для вебхука нужны права timeman и user.

Зависимости (добавить в requirements.txt):
  apscheduler>=3.10
  httpx
  pytz
"""

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
import asyncio
import logging
import os
import time
from datetime import date, datetime, timezone
from typing import Optional
from zoneinfo import ZoneInfo   # Python 3.9+

import httpx
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from fastapi import APIRouter, HTTPException, Query

from db import get_conn

router = APIRouter(prefix="/api/timeman", tags=["timeman"])
logger = logging.getLogger(__name__)

# ── Конфиг ──────────────────────────────────────────────────
BX_WEBHOOK        = os.getenv("BX_WEBHOOK", "")          # https://domain/rest/1/token/
TABLE_DAILY       = os.getenv("DB_TABLE_DAILY", "payroll_daily")
CRON_TIME         = os.getenv("CRON_DAILY_SAVE_TIME", "23:30")   # HH:MM МСК
CRON_SECRET       = os.getenv("CRON_SECRET", "")                  # для ручного запуска
B24_RATE_DELAY    = 0.55   # сек между запросами (лимит Б24 ~2 req/sec)
MSK               = ZoneInfo("Europe/Moscow")

# ── Кэш пользователей ────────────────────────────────────────
_users_cache: list        = []
_users_cache_at: float    = 0.0
USERS_CACHE_TTL: int      = 600   # 10 минут

# ── Планировщик (singleton) ──────────────────────────────────
_scheduler: Optional[AsyncIOScheduler] = None


# ============================================================
# Вспомогательные функции — Б24 API через вебхук
# ============================================================

async def _bx_call(method: str, params: dict) -> Optional[dict]:
    """
    GET-запрос к Б24 REST API через вебхук.
    Возвращает resp.data["result"] или None при ошибке.
    """
    if not BX_WEBHOOK:
        logger.error("BX_WEBHOOK не задан в env")
        return None

    url = f"{BX_WEBHOOK.rstrip('/')}/{method}"
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
            data = resp.json()
    except Exception as e:
        logger.error(f"B24 {method} error: {e}")
        return None

    if "error" in data:
        logger.error(f"B24 {method} API error: {data.get('error_description', data['error'])}")
        return None

    return data.get("result")


def _parse_timeman(ts: Optional[dict]) -> dict:
    """
    Разбирает ответ timeman.status в единый формат.
    Повторяет логику time_calc.js — три случая: CLOSED, DURATION, открытый день.
    """
    null_result = {
        "hours": 0.0, "duration_sec": 0,
        "status": "unknown", "has_data": False,
        "time_start": None, "time_finish": None, "b24_status": None,
    }

    if not ts:
        return null_result

    b24_status = ts.get("STATUS", "")

    # Случай 1: день закрыт (CLOSED)
    if b24_status in ("CLOSED", "EXPIRED") and ts.get("TIME_START"):
        finish_raw = ts.get("TIME_FINISH") or ts.get("TIME_FINISH_DEFAULT")
        if not finish_raw:
            pass  # упадём в случай 2 через DURATION
        else:
            try:
                s = datetime.fromisoformat(ts["TIME_START"])
                f = datetime.fromisoformat(finish_raw)
                dur = max(0, (f - s).total_seconds())
                return {
                    "hours": round(dur / 3600, 2),
                    "duration_sec": int(dur),
                    "status": "expired" if b24_status == "EXPIRED" else "closed",
                    "has_data": True,
                    "time_start": ts["TIME_START"],
                    "time_finish": finish_raw,
                    "b24_status": b24_status,
                }
            except Exception:
                pass

    # Случай 2: есть готовый DURATION
    duration_raw = ts.get("DURATION")
    if duration_raw is not None:
        dur_sec = 0
        if isinstance(duration_raw, (int, float)):
            dur_sec = int(duration_raw)
        elif isinstance(duration_raw, str) and ":" in duration_raw:
            parts = duration_raw.split(":")
            try:
                dur_sec = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2] if len(parts) > 2 else 0)
            except Exception:
                pass

        # Добавляем перерывы TIME_LEAKS
        leaks_raw = ts.get("TIME_LEAKS", "")
        if leaks_raw and ":" in str(leaks_raw):
            try:
                parts = str(leaks_raw).split(":")
                dur_sec += int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2] if len(parts) > 2 else 0)
            except Exception:
                pass

        return {
            "hours":        round(dur_sec / 3600, 2),
            "duration_sec": dur_sec,
            "status":       ts.get("CURRENT_STATUS", "closed").lower(),
            "has_data":     True,
            "time_start":   ts.get("TIME_START"),
            "time_finish":  ts.get("TIME_FINISH"),
            "b24_status":   b24_status,
        }

    # Случай 3: день открыт (нет TIME_FINISH)
    if ts.get("TIME_START") and not ts.get("TIME_FINISH"):
        try:
            s = datetime.fromisoformat(ts["TIME_START"])
            dur = max(0, (datetime.now(s.tzinfo or timezone.utc) - s).total_seconds())
            return {
                "hours":        round(dur / 3600, 2),
                "duration_sec": int(dur),
                "status":       "open",
                "has_data":     True,
                "time_start":   ts["TIME_START"],
                "time_finish":  None,
                "b24_status":   b24_status,
            }
        except Exception:
            pass

    return null_result


# ============================================================
# Кэшированный список пользователей
# ============================================================

async def _get_active_users(force: bool = False) -> list:
    """
    Возвращает список активных сотрудников из Б24.
    Кэшируется на USERS_CACHE_TTL секунд.
    """
    global _users_cache, _users_cache_at

    if not force and _users_cache and (time.monotonic() - _users_cache_at) < USERS_CACHE_TTL:
        return _users_cache

    all_users: list = []
    start = 0

    while True:
        result = await _bx_call("user.get", {
            "ACTIVE":      True,
            "USER_TYPE":   "employee",
            "SORT":        "ID",
            "ORDER":       "asc",
            "SELECT[]":    ["ID", "NAME", "LAST_NAME", "WORK_POSITION"],
            "start":       start,
        })
        if not result:
            break

        batch = result if isinstance(result, list) else []
        all_users.extend(batch)

        # Б24 возвращает next в теле ответа — но через _bx_call мы теряем next.
        # Используем стандартный признак: если вернулось 50 записей — продолжаем.
        if len(batch) < 50:
            break
        start += 50

    _users_cache    = all_users
    _users_cache_at = time.monotonic()
    logger.info(f"[users cache] Загружено {len(all_users)} сотрудников")
    return all_users


# ============================================================
# Крон: автосохранение часов за день
# ============================================================

async def _save_daily_hours(target_date: Optional[date] = None) -> dict:
    """
    Основная функция крона.
    Опрашивает timeman.status для всех активных сотрудников,
    сохраняет в payroll_daily со статусом 'auto_cron'.
    Записи foreman_approved и manual_override не трогает.

    Возвращает статистику: { saved, skipped, errors, date }.
    """
    report_date = target_date or date.today()
    logger.info(f"[cron] Начало сохранения за {report_date}...")

    users = await _get_active_users()
    if not users:
        logger.error("[cron] Не удалось получить список сотрудников")
        return {"saved": 0, "skipped": 0, "errors": 1, "date": str(report_date)}

    saved = skipped = errors = 0

    # Загружаем уже защищённые записи за эту дату
    protected_ids: set = set()
    async with get_conn() as (_, cur):
        await cur.execute(
            f"""
            SELECT employee_id FROM `{TABLE_DAILY}`
            WHERE report_date = %s
              AND source IN ('foreman_approved', 'manual_override')
            """,
            (report_date,)
        )
        rows = await cur.fetchall()
        protected_ids = {str(r["employee_id"]) for r in rows}

    logger.info(f"[cron] Защищённых записей: {len(protected_ids)}, всего сотрудников: {len(users)}")

    for user in users:
        uid  = str(user.get("ID", ""))
        name = f"{user.get('NAME', '')} {user.get('LAST_NAME', '')}".strip()

        if uid in protected_ids:
            skipped += 1
            continue

        await asyncio.sleep(B24_RATE_DELAY)

        try:
            ts_result = await _bx_call("timeman.status", {"USER_ID": int(uid)})
            calc      = _parse_timeman(ts_result)

            if not calc["has_data"] and calc["status"] != "closed":
                # Нет данных — не пишем строку (сотрудник не работал)
                continue

            hours = round(calc["hours"], 2)

            async with get_conn() as (_, cur):
                await cur.execute(
                    f"""
                    INSERT INTO `{TABLE_DAILY}`
                        (employee_id, employee_name, report_date, hours, duration_sec,
                         b24_status, source)
                    VALUES (%s, %s, %s, %s, %s, %s, 'auto_cron')
                    ON DUPLICATE KEY UPDATE
                        hours        = IF(source = 'auto_cron', VALUES(hours),        hours),
                        duration_sec = IF(source = 'auto_cron', VALUES(duration_sec), duration_sec),
                        b24_status   = IF(source = 'auto_cron', VALUES(b24_status),   b24_status),
                        updated_at   = IF(source = 'auto_cron', CURRENT_TIMESTAMP,    updated_at)
                    """,
                    (uid, name, report_date, hours,
                     calc["duration_sec"], calc["b24_status"] or "")
                )
            saved += 1
            logger.debug(f"[cron] {name} ({uid}): {hours} ч ({calc['status']})")

        except Exception as e:
            errors += 1
            logger.error(f"[cron] User {uid} ({name}) error: {e}")

    logger.info(f"[cron] Готово: сохранено={saved}, пропущено={skipped}, ошибок={errors}")
    return {"saved": saved, "skipped": skipped, "errors": errors, "date": str(report_date)}


# ============================================================
# APScheduler
# ============================================================

def start_cron():
    """
    Запускает планировщик. Вызывается из main.py lifespan.
    Время из env CRON_DAILY_SAVE_TIME формата HH:MM, часовой пояс МСК.
    """
    global _scheduler

    try:
        h, m = CRON_TIME.split(":")
        hour, minute = int(h), int(m)
    except Exception:
        logger.error(f"Неверный формат CRON_DAILY_SAVE_TIME: '{CRON_TIME}'. Используем 23:30.")
        hour, minute = 23, 30

    _scheduler = AsyncIOScheduler(timezone=MSK)
    _scheduler.add_job(
        _save_daily_hours,
        CronTrigger(hour=hour, minute=minute, timezone=MSK),
        id="daily_save",
        name=f"Авто-сохранение часов {hour:02d}:{minute:02d} МСК",
        misfire_grace_time=300,   # 5 минут опоздания — всё равно запускаем
    )
    _scheduler.start()
    logger.info(f"[cron] Планировщик запущен: {hour:02d}:{minute:02d} МСК ежедневно")


def stop_cron():
    """Останавливает планировщик. Вызывается из main.py lifespan."""
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("[cron] Планировщик остановлен")


# ============================================================
# Эндпоинты
# ============================================================

@router.get("/users")
async def get_users(force_refresh: bool = Query(False)):
    """
    Список активных сотрудников Б24.
    Кэшируется 10 минут. force_refresh=true сбрасывает кэш.
    """
    users = await _get_active_users(force=force_refresh)
    return [
        {
            "id":       str(u.get("ID", "")),
            "name":     f"{u.get('NAME', '')} {u.get('LAST_NAME', '')}".strip(),
            "position": u.get("WORK_POSITION", ""),
        }
        for u in users
    ]


@router.get("/team-status")
async def team_status(
    user_ids: str = Query(..., description="ID через запятую"),
):
    """
    Опрашивает timeman.status для списка сотрудников.
    Возвращает { user_id: { hours, duration_sec, status, has_data, time_start, time_finish, b24_status } }.

    Задержка 550мс между запросами — лимит Б24 ~2 req/sec.
    При 30 сотрудниках ≈ 17 сек. Фронтенд показывает прогресс-бар.
    """
    ids = [x.strip() for x in user_ids.split(",") if x.strip()]
    if not ids:
        raise HTTPException(400, "Пустой список user_ids")
    if len(ids) > 200:
        raise HTTPException(400, "Максимум 200 сотрудников за один запрос")

    result: dict = {}

    for uid in ids:
        await asyncio.sleep(B24_RATE_DELAY)
        try:
            ts_result = await _bx_call("timeman.status", {"USER_ID": int(uid)})
            result[uid] = _parse_timeman(ts_result)
        except Exception as e:
            logger.error(f"team-status user {uid}: {e}")
            result[uid] = {
                "hours": 0.0, "duration_sec": 0, "status": "error",
                "has_data": False, "time_start": None, "time_finish": None, "b24_status": None,
            }

    return result


@router.post("/cron/run")
async def manual_cron(
    secret: str = Query("", description="CRON_SECRET из env"),
    target_date: Optional[str] = Query(None, description="YYYY-MM-DD, по умолчанию сегодня"),
):
    """
    Ручной запуск крона для отладки или повторного сохранения.
    Требует ?secret=<CRON_SECRET> из env.
    """
    if CRON_SECRET and secret != CRON_SECRET:
        raise HTTPException(403, "Неверный secret")

    d: Optional[date] = None
    if target_date:
        try:
            d = date.fromisoformat(target_date)
        except ValueError:
            raise HTTPException(400, f"Неверный формат даты: {target_date}")

    stats = await _save_daily_hours(d)
    return {"ok": True, **stats}
