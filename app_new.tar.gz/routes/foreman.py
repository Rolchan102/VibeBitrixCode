"""
foreman.py — роутер отчётов прораба (бывший reports.py).

Изменения относительно reports.py:
  - Префикс /api/report → /api/foreman
  - После confirmed_at пишет в payroll_daily (source='foreman_approved')
    вместо вызова Node.js
  - Убран _approve_in_node() — Node.js больше нет
  - sync_to_sheets запускается subprocess'ом как раньше
  - Модели EntryIn расширены: duration_sec, b24_status

Эндпоинты:
  GET  /api/foreman/status   — отправлен ли отчёт сегодня
  GET  /api/foreman/view     — просмотр подтверждённого отчёта
  POST /api/foreman/submit   — подтвердить отчёт
"""

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
import asyncio
import logging
import os
from datetime import date, datetime
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from db import get_conn
from bitrix_notify import send_report_to_chat

router = APIRouter(prefix="/api/foreman", tags=["foreman"])
logger = logging.getLogger(__name__)

FLAT        = os.getenv("DB_TABLE",       "worktime_flat")
TABLE_DAILY = os.getenv("DB_TABLE_DAILY", "payroll_daily")
SYNC_SCRIPT = os.path.join(os.path.dirname(__file__), "..", "sync_to_sheets.py")


# ============================================================
# Pydantic-модели
# ============================================================

class EntryIn(BaseModel):
    user_id:        str
    user_name:      str = ""
    raw_start:      Optional[str] = None
    raw_end:        Optional[str] = None
    adjusted_start: str
    adjusted_end:   str
    lunch_minutes:  int = 0
    duration_sec:   int = 0       # raw duration из timeman.status (секунды)
    b24_status:     str = ""      # STATUS из timeman (OPENED/CLOSED/...)


class ReportIn(BaseModel):
    foreman_id:   str
    foreman_name: str = ""
    entries:      List[EntryIn]


# ============================================================
# Вспомогательные функции
# ============================================================

def _parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None


def _calc_total_minutes(adj_start: datetime, adj_end: datetime, lunch_minutes: int) -> int:
    delta = int((adj_end - adj_start).total_seconds() // 60)
    return max(0, delta - lunch_minutes)


async def _run_sync_sheets():
    """Запускает sync_to_sheets.py как subprocess (не блокирует event loop)."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "python3", SYNC_SCRIPT,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logger.error(f"sync_to_sheets error: {stderr.decode()[:300]}")
        else:
            logger.info(f"sync_to_sheets ok: {stdout.decode().strip()[:200]}")
    except Exception as e:
        logger.exception(f"sync_to_sheets exception: {e}")


async def _send_notify(report_date: str, foreman_name: str, entries: list):
    """Отправляет отчёт в групповой чат Б24."""
    await send_report_to_chat(
        report_date=report_date,
        foreman_name=foreman_name,
        entries=entries,
    )


async def _write_payroll_daily(
    report_date: date,
    foreman_id: str,
    foreman_name: str,
    entries: List[EntryIn],
    total_minutes_map: dict,   # { user_id: total_minutes }
):
    """
    Записывает подтверждённые часы в payroll_daily (source='foreman_approved').

    Логика приоритетов:
      - foreman_approved перезаписывает auto_cron
      - foreman_approved НЕ перезаписывает manual_override
        (ручная правка бухгалтера приоритетнее прораба)
    """
    for e in entries:
        total_min = total_minutes_map.get(e.user_id, 0)
        hours     = round(total_min / 60, 2)

        try:
            async with get_conn() as (_, cur):
                await cur.execute(
                    f"""
                    INSERT INTO `{TABLE_DAILY}`
                        (employee_id, employee_name, report_date, hours, duration_sec,
                         b24_status, source, approved_by, approved_by_id)
                    VALUES (%s, %s, %s, %s, %s, %s, 'foreman_approved', %s, %s)
                    ON DUPLICATE KEY UPDATE
                        hours          = IF(source != 'manual_override', VALUES(hours),        hours),
                        duration_sec   = IF(source != 'manual_override', VALUES(duration_sec), duration_sec),
                        b24_status     = IF(source != 'manual_override', VALUES(b24_status),   b24_status),
                        source         = IF(source != 'manual_override', 'foreman_approved',   source),
                        approved_by    = IF(source != 'manual_override', VALUES(approved_by),  approved_by),
                        approved_by_id = IF(source != 'manual_override', VALUES(approved_by_id), approved_by_id),
                        updated_at     = IF(source != 'manual_override', CURRENT_TIMESTAMP,    updated_at)
                    """,
                    (e.user_id, e.user_name, report_date, hours,
                     e.duration_sec, e.b24_status or "",
                     foreman_name, foreman_id)
                )
        except Exception as ex:
            logger.error(f"_write_payroll_daily user={e.user_id}: {ex}")

    logger.info(
        f"payroll_daily: записано {len(entries)} строк за {report_date} "
        f"(прораб: {foreman_name})"
    )


# ============================================================
# Эндпоинты
# ============================================================

@router.get("/status")
async def foreman_status(foreman_id: str, report_date: Optional[str] = None):
    """
    Проверяет, отправлен ли уже отчёт прорабом за дату.
    Если не передана — используется сегодня.
    """
    rdate = date.fromisoformat(report_date) if report_date else date.today()

    async with get_conn() as (_, cur):
        await cur.execute(
            f"""
            SELECT MIN(confirmed_at) AS submitted_at
            FROM `{FLAT}`
            WHERE foreman_id = %s
              AND report_date = %s
              AND confirmed_at IS NOT NULL
            """,
            (foreman_id, rdate),
        )
        row = await cur.fetchone()

    if row and row["submitted_at"]:
        return {
            "submitted":    True,
            "submitted_at": row["submitted_at"].isoformat(),
        }
    return {"submitted": False}


@router.get("/view")
async def foreman_view(foreman_id: str, report_date: Optional[str] = None):
    """
    Возвращает подтверждённый отчёт прораба для просмотра (шаг 3 фронтенда).
    """
    rdate = date.fromisoformat(report_date) if report_date else date.today()

    async with get_conn() as (_, cur):
        await cur.execute(
            f"""
            SELECT *
            FROM `{FLAT}`
            WHERE foreman_id = %s AND report_date = %s
            ORDER BY user_name
            """,
            (foreman_id, rdate),
        )
        rows = await cur.fetchall()

    if not rows:
        raise HTTPException(404, "Отчёт не найден")

    first = rows[0]

    def _fmt(r: dict) -> dict:
        return {
            "user_id":        r["user_id"],
            "user_name":      r["user_name"],
            "raw_start":      r["raw_start"].isoformat()       if r["raw_start"]       else None,
            "raw_end":        r["raw_end"].isoformat()         if r["raw_end"]         else None,
            "adjusted_start": r["adjusted_start"].isoformat(),
            "adjusted_end":   r["adjusted_end"].isoformat(),
            "lunch_minutes":  r["lunch_minutes"],
            "total_minutes":  r["total_minutes"],
        }

    return {
        "foreman_id":   first["foreman_id"],
        "foreman_name": first["foreman_name"],
        "report_date":  first["report_date"].isoformat(),
        "submitted_at": first["confirmed_at"].isoformat(),
        "entries":      [_fmt(r) for r in rows],
    }


@router.post("/submit")
async def foreman_submit(body: ReportIn):
    """
    Подтверждает отчёт прораба.

    1. Проверяет что отчёт не отправлен повторно (409 если уже есть).
    2. Для каждого сотрудника: UPDATE или INSERT в worktime_flat с confirmed_at.
    3. Фоново: пишет в payroll_daily, шлёт уведомление в чат, синкает Sheets.
    """
    rdate        = date.today()
    confirmed_at = datetime.now()

    async with get_conn() as (_, cur):

        # ── Защита от повторного submit ──────────────────────
        await cur.execute(
            f"""
            SELECT COUNT(*) AS cnt
            FROM `{FLAT}`
            WHERE foreman_id = %s AND report_date = %s AND confirmed_at IS NOT NULL
            """,
            (body.foreman_id, rdate),
        )
        if (await cur.fetchone())["cnt"] > 0:
            raise HTTPException(409, "Отчёт за сегодня уже отправлен и заблокирован")

        # ── Обрабатываем каждую запись ───────────────────────
        notify_entries:  list = []   # для уведомления в чат
        total_min_map:   dict = {}   # для payroll_daily

        for e in body.entries:
            adj_s = _parse_dt(e.adjusted_start)
            adj_e = _parse_dt(e.adjusted_end)

            if not adj_s or not adj_e:
                raise HTTPException(400, f"Некорректное время для {e.user_id}")
            if adj_e <= adj_s:
                raise HTTPException(400, f"Конец раньше начала для {e.user_id}")

            total_min = _calc_total_minutes(adj_s, adj_e, e.lunch_minutes)
            total_min_map[e.user_id] = total_min

            # Ищем существующую неподтверждённую запись
            await cur.execute(
                f"""
                SELECT id FROM `{FLAT}`
                WHERE user_id = %s AND report_date = %s AND confirmed_at IS NULL
                LIMIT 1
                """,
                (e.user_id, rdate),
            )
            existing = await cur.fetchone()

            if existing:
                await cur.execute(
                    f"""
                    UPDATE `{FLAT}` SET
                        adjusted_start = %s,
                        adjusted_end   = %s,
                        lunch_minutes  = %s,
                        total_minutes  = %s,
                        foreman_id     = %s,
                        foreman_name   = %s,
                        confirmed_at   = %s
                    WHERE id = %s
                    """,
                    (adj_s, adj_e, e.lunch_minutes, total_min,
                     body.foreman_id, body.foreman_name,
                     confirmed_at, existing["id"]),
                )
            else:
                # Прораб добавляет сотрудника у которого не было timeman-записи
                await cur.execute(
                    f"""
                    INSERT INTO `{FLAT}`
                        (user_id, user_name,
                         raw_start, raw_end,
                         adjusted_start, adjusted_end,
                         lunch_minutes, total_minutes,
                         foreman_id, foreman_name,
                         confirmed_at, report_date)
                    VALUES (%s, %s, NULL, NULL, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (e.user_id, e.user_name,
                     adj_s, adj_e,
                     e.lunch_minutes, total_min,
                     body.foreman_id, body.foreman_name,
                     confirmed_at, rdate),
                )

            notify_entries.append({
                "user_name":      e.user_name,
                "adjusted_start": e.adjusted_start,
                "adjusted_end":   e.adjusted_end,
                "lunch_minutes":  e.lunch_minutes,
                "total_minutes":  total_min,
            })

    # ── Фоновые задачи ────────────────────────────────────────
    # Все три независимы — падение одной не влияет на другие.
    async def _bg():
        await asyncio.gather(
            _write_payroll_daily(
                report_date=rdate,
                foreman_id=body.foreman_id,
                foreman_name=body.foreman_name,
                entries=body.entries,
                total_minutes_map=total_min_map,
            ),
            _send_notify(
                report_date=rdate.isoformat(),
                foreman_name=body.foreman_name,
                entries=notify_entries,
            ),
            _run_sync_sheets(),
            return_exceptions=True,   # логируем ошибки, не прерываем
        )

    asyncio.create_task(_bg())

    return {"ok": True, "entries_count": len(body.entries)}
