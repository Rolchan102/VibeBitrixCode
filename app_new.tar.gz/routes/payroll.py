"""
payroll.py — роутер учёта выплат.

Эндпоинты:
  GET  /api/payroll/report          — месячный отчёт по всем сотрудникам
  GET  /api/payroll/report/employee — отчёт по одному сотруднику
  POST /api/payroll/rate            — установить ставку
  POST /api/payroll/bonus           — установить премию
  POST /api/payroll/adjust-daily    — ручная правка часов за день
  GET  /api/payroll/daily-detail    — детализация по одному дню

Роли (из конфига):
  ADMIN_IDS  — видят всех сотрудников, меняют ставки/премии
  FOREMAN_IDS — видят только своих (фильтр на стороне фронта)

Хранилище: MySQL, таблицы payroll_daily + payroll_rates.
Дефолтная ставка: env PAYROLL_DEFAULT_RATE (число, руб./час).
"""

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
import os
import logging
from typing import Optional, List
from datetime import date, datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from db import get_conn

router = APIRouter(prefix="/api/payroll", tags=["payroll"])
logger = logging.getLogger(__name__)

# ── Конфиг ──────────────────────────────────────────────────
TABLE_RATES = os.getenv("DB_TABLE_RATES",   "payroll_rates")
TABLE_DAILY = os.getenv("DB_TABLE_DAILY",   "payroll_daily")
DEFAULT_RATE = Decimal(os.getenv("PAYROLL_DEFAULT_RATE", "500"))


# ============================================================
# Pydantic-модели
# ============================================================

class RateIn(BaseModel):
    employee_id:   str
    employee_name: str = ""
    month:         str            # YYYY-MM
    rate:          float
    updated_by:    str = ""


class BonusIn(BaseModel):
    employee_id:   str
    employee_name: str = ""
    month:         str
    bonus:         float
    updated_by:    str = ""


class AdjustDailyIn(BaseModel):
    employee_id:   str
    employee_name: str = ""
    date:          str            # YYYY-MM-DD
    hours:         float
    updated_by:    str = ""


# ============================================================
# Вспомогательные функции
# ============================================================

def _validate_month(month: str):
    """Проверяет формат YYYY-MM, возвращает (year, mon) int."""
    try:
        parts = month.split("-")
        assert len(parts) == 2
        y, m = int(parts[0]), int(parts[1])
        assert 1 <= m <= 12
        return y, m
    except Exception:
        raise HTTPException(400, f"Неверный формат month: '{month}'. Ожидается YYYY-MM")


def _validate_date(d: str) -> date:
    try:
        return date.fromisoformat(d)
    except Exception:
        raise HTTPException(400, f"Неверный формат date: '{d}'. Ожидается YYYY-MM-DD")


def _days_in_month(year: int, month: int) -> List[str]:
    """Возвращает список строк YYYY-MM-DD для всех дней месяца."""
    first = date(year, month, 1)
    if month == 12:
        last = date(year + 1, 1, 1) - timedelta(days=1)
    else:
        last = date(year, month + 1, 1) - timedelta(days=1)
    days = []
    cur = first
    while cur <= last:
        days.append(cur.isoformat())
        cur += timedelta(days=1)
    return days


async def _get_rate(cur, employee_id: str, month: str) -> Decimal:
    """
    Возвращает ставку сотрудника за месяц.
    Если нет записи за текущий месяц — ищет ближайшую предыдущую
    (до 6 месяцев назад), затем дефолт из env.
    """
    # Точное совпадение
    await cur.execute(
        f"SELECT rate FROM `{TABLE_RATES}` WHERE employee_id=%s AND month=%s",
        (employee_id, month)
    )
    row = await cur.fetchone()
    if row:
        return Decimal(str(row["rate"]))

    # Ищем предыдущие месяцы (до 6)
    year, mon = _validate_month(month)
    for i in range(1, 7):
        m = mon - i
        y = year
        while m <= 0:
            m += 12
            y -= 1
        prev = f"{y}-{m:02d}"
        await cur.execute(
            f"SELECT rate FROM `{TABLE_RATES}` WHERE employee_id=%s AND month=%s",
            (employee_id, prev)
        )
        row = await cur.fetchone()
        if row:
            return Decimal(str(row["rate"]))

    return DEFAULT_RATE


async def _get_bonus(cur, employee_id: str, month: str) -> Decimal:
    await cur.execute(
        f"SELECT bonus FROM `{TABLE_RATES}` WHERE employee_id=%s AND month=%s",
        (employee_id, month)
    )
    row = await cur.fetchone()
    return Decimal(str(row["bonus"])) if row else Decimal("0")


# ============================================================
# Эндпоинты — ставки и премии
# ============================================================

@router.post("/rate")
async def set_rate(body: RateIn):
    """Установить ставку сотрудника за месяц (upsert)."""
    _validate_month(body.month)
    if body.rate < 0:
        raise HTTPException(400, "Ставка не может быть отрицательной")

    async with get_conn() as (conn, cur):
        await cur.execute(
            f"""
            INSERT INTO `{TABLE_RATES}` (employee_id, employee_name, month, rate, updated_by)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                rate         = VALUES(rate),
                employee_name = VALUES(employee_name),
                updated_by   = VALUES(updated_by),
                updated_at   = CURRENT_TIMESTAMP
            """,
            (body.employee_id, body.employee_name, body.month,
             round(body.rate, 2), body.updated_by)
        )

    logger.info(f"Rate set: emp={body.employee_id} month={body.month} rate={body.rate} by={body.updated_by}")
    return {"ok": True, "employee_id": body.employee_id, "month": body.month, "rate": body.rate}


@router.post("/bonus")
async def set_bonus(body: BonusIn):
    """Установить премию сотрудника за месяц (upsert)."""
    _validate_month(body.month)
    if body.bonus < 0:
        raise HTTPException(400, "Премия не может быть отрицательной")

    async with get_conn() as (conn, cur):
        await cur.execute(
            f"""
            INSERT INTO `{TABLE_RATES}` (employee_id, employee_name, month, bonus, updated_by)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                bonus         = VALUES(bonus),
                employee_name = VALUES(employee_name),
                updated_by    = VALUES(updated_by),
                updated_at    = CURRENT_TIMESTAMP
            """,
            (body.employee_id, body.employee_name, body.month,
             round(body.bonus, 2), body.updated_by)
        )

    logger.info(f"Bonus set: emp={body.employee_id} month={body.month} bonus={body.bonus} by={body.updated_by}")
    return {"ok": True, "employee_id": body.employee_id, "month": body.month, "bonus": body.bonus}


# ============================================================
# Эндпоинты — ручная правка часов
# ============================================================

@router.post("/adjust-daily")
async def adjust_daily(body: AdjustDailyIn):
    """
    Ручная правка часов за конкретный день (manual_override).
    Перезаписывает любой источник включая foreman_approved.
    Только для ADMIN_IDS.
    """
    d = _validate_date(body.date)
    if body.hours < 0 or body.hours > 24:
        raise HTTPException(400, "Часы должны быть от 0 до 24")

    async with get_conn() as (conn, cur):
        await cur.execute(
            f"""
            INSERT INTO `{TABLE_DAILY}`
                (employee_id, employee_name, report_date, hours, source, approved_by)
            VALUES (%s, %s, %s, %s, 'manual_override', %s)
            ON DUPLICATE KEY UPDATE
                hours         = VALUES(hours),
                source        = 'manual_override',
                approved_by   = VALUES(approved_by),
                updated_at    = CURRENT_TIMESTAMP
            """,
            (body.employee_id, body.employee_name, d,
             round(body.hours, 2), body.updated_by)
        )

    logger.info(f"Manual override: emp={body.employee_id} date={body.date} hours={body.hours} by={body.updated_by}")
    return {"ok": True, "date": body.date, "hours": body.hours}


# ============================================================
# Эндпоинты — отчёты
# ============================================================

@router.get("/report")
async def monthly_report(
    month: str = Query(..., description="YYYY-MM"),
    employee_ids: Optional[str] = Query(None, description="Фильтр: ID через запятую"),
):
    """
    Месячный отчёт по всем (или выбранным) сотрудникам.

    Возвращает:
    [
      {
        "employee_id": "42",
        "employee_name": "Иван Иванов",
        "rate": 500.0,
        "bonus": 0.0,
        "total_hours": 168.5,
        "total_salary": 84250.0,
        "days": {
          "2026-05-01": { "hours": 8.5, "source": "foreman_approved" },
          ...
        }
      }
    ]
    """
    year, mon = _validate_month(month)
    days = _days_in_month(year, mon)

    # Фильтр по сотрудникам
    id_filter: Optional[List[str]] = None
    if employee_ids:
        id_filter = [x.strip() for x in employee_ids.split(",") if x.strip()]

    async with get_conn() as (conn, cur):
        # 1. Все часы за месяц
        if id_filter:
            fmt = ",".join(["%s"] * len(id_filter))
            await cur.execute(
                f"""
                SELECT employee_id, employee_name, report_date, hours, source
                FROM `{TABLE_DAILY}`
                WHERE report_date BETWEEN %s AND %s
                  AND employee_id IN ({fmt})
                ORDER BY employee_id, report_date
                """,
                [days[0], days[-1]] + id_filter
            )
        else:
            await cur.execute(
                f"""
                SELECT employee_id, employee_name, report_date, hours, source
                FROM `{TABLE_DAILY}`
                WHERE report_date BETWEEN %s AND %s
                ORDER BY employee_id, report_date
                """,
                (days[0], days[-1])
            )
        daily_rows = await cur.fetchall()

        # 2. Ставки и премии за месяц
        if id_filter:
            fmt = ",".join(["%s"] * len(id_filter))
            await cur.execute(
                f"""
                SELECT employee_id, employee_name, rate, bonus
                FROM `{TABLE_RATES}`
                WHERE month=%s AND employee_id IN ({fmt})
                """,
                [month] + id_filter
            )
        else:
            await cur.execute(
                f"SELECT employee_id, employee_name, rate, bonus FROM `{TABLE_RATES}` WHERE month=%s",
                (month,)
            )
        rate_rows = await cur.fetchall()

        # 3. Ставки из предыдущих месяцев для тех у кого нет за текущий
        #    (собираем employee_id без записи в TABLE_RATES за этот месяц)
        known_rate_ids = {str(r["employee_id"]) for r in rate_rows}

        # Все employee_id из daily кто есть в периоде
        all_emp_ids = list({str(r["employee_id"]) for r in daily_rows})

        missing_ids = [eid for eid in all_emp_ids if eid not in known_rate_ids]
        inherited_rates: dict = {}

        for eid in missing_ids:
            # Ищем последнюю ставку за предыдущие 6 месяцев
            for i in range(1, 7):
                m = mon - i
                y = year
                while m <= 0:
                    m += 12
                    y -= 1
                prev = f"{y}-{m:02d}"
                await cur.execute(
                    f"SELECT rate, bonus FROM `{TABLE_RATES}` WHERE employee_id=%s AND month=%s",
                    (eid, prev)
                )
                row = await cur.fetchone()
                if row:
                    inherited_rates[eid] = {
                        "rate":  Decimal(str(row["rate"])),
                        "bonus": Decimal(str(row["bonus"])),
                    }
                    break

    # ── Сборка отчёта ──────────────────────────────────────
    # Индекс ставок
    rates_index: dict = {str(r["employee_id"]): r for r in rate_rows}

    # Индекс часов: { employee_id: { date_str: { hours, source } } }
    hours_index: dict = {}
    names_index: dict = {}
    for r in daily_rows:
        eid   = str(r["employee_id"])
        dstr  = r["report_date"].isoformat() if hasattr(r["report_date"], "isoformat") else str(r["report_date"])
        if eid not in hours_index:
            hours_index[eid] = {}
        hours_index[eid][dstr] = {
            "hours":  float(r["hours"]),
            "source": r["source"],
        }
        names_index[eid] = r["employee_name"] or ""

    result = []
    for eid in all_emp_ids:
        rate_row = rates_index.get(eid)
        if rate_row:
            rate  = float(rate_row["rate"])
            bonus = float(rate_row["bonus"])
            name  = rate_row["employee_name"] or names_index.get(eid, "")
        else:
            inh   = inherited_rates.get(eid, {})
            rate  = float(inh.get("rate",  DEFAULT_RATE))
            bonus = float(inh.get("bonus", Decimal("0")))
            name  = names_index.get(eid, "")

        emp_days = hours_index.get(eid, {})
        days_out = {}
        total_hours = 0.0

        for d in days:
            entry = emp_days.get(d)
            if entry:
                days_out[d] = entry
                total_hours += entry["hours"]
            else:
                days_out[d] = {"hours": 0.0, "source": None}

        total_hours  = round(total_hours, 2)
        total_salary = round(total_hours * rate + bonus, 2)

        result.append({
            "employee_id":   eid,
            "employee_name": name,
            "rate":          rate,
            "bonus":         bonus,
            "total_hours":   total_hours,
            "total_salary":  total_salary,
            "days":          days_out,
        })

    # Сортируем по имени
    result.sort(key=lambda x: x["employee_name"].lower())
    return result


@router.get("/report/employee")
async def employee_report(
    employee_id: str = Query(...),
    month:       str = Query(..., description="YYYY-MM"),
):
    """Детальный отчёт по одному сотруднику за месяц."""
    year, mon = _validate_month(month)
    days = _days_in_month(year, mon)

    async with get_conn() as (conn, cur):
        await cur.execute(
            f"""
            SELECT report_date, hours, duration_sec, b24_status, source,
                   approved_by, updated_at
            FROM `{TABLE_DAILY}`
            WHERE employee_id=%s AND report_date BETWEEN %s AND %s
            ORDER BY report_date
            """,
            (employee_id, days[0], days[-1])
        )
        daily_rows = await cur.fetchall()

        await cur.execute(
            f"SELECT rate, bonus, employee_name FROM `{TABLE_RATES}` WHERE employee_id=%s AND month=%s",
            (employee_id, month)
        )
        rate_row = await cur.fetchone()

    # Наследуем ставку если нет за этот месяц
    if rate_row:
        rate  = float(rate_row["rate"])
        bonus = float(rate_row["bonus"])
        name  = rate_row["employee_name"]
    else:
        async with get_conn() as (conn, cur):
            for i in range(1, 7):
                m = mon - i
                y = year
                while m <= 0:
                    m += 12
                    y -= 1
                prev = f"{y}-{m:02d}"
                await cur.execute(
                    f"SELECT rate, bonus, employee_name FROM `{TABLE_RATES}` WHERE employee_id=%s AND month=%s",
                    (employee_id, prev)
                )
                row = await cur.fetchone()
                if row:
                    rate  = float(row["rate"])
                    bonus = float(row["bonus"])
                    name  = row["employee_name"]
                    break
            else:
                rate, bonus, name = float(DEFAULT_RATE), 0.0, ""

    # Индекс
    daily_index: dict = {}
    for r in daily_rows:
        dstr = r["report_date"].isoformat() if hasattr(r["report_date"], "isoformat") else str(r["report_date"])
        daily_index[dstr] = {
            "hours":        float(r["hours"]),
            "duration_sec": r["duration_sec"],
            "b24_status":   r["b24_status"],
            "source":       r["source"],
            "approved_by":  r["approved_by"],
            "updated_at":   r["updated_at"].isoformat() if r["updated_at"] else None,
        }

    days_out = {}
    total_hours = 0.0
    for d in days:
        entry = daily_index.get(d)
        if entry:
            days_out[d] = entry
            total_hours += entry["hours"]
        else:
            days_out[d] = {
                "hours": 0.0, "duration_sec": 0, "b24_status": "",
                "source": None, "approved_by": "", "updated_at": None,
            }

    total_hours  = round(total_hours, 2)
    total_salary = round(total_hours * rate + bonus, 2)

    return {
        "employee_id":   employee_id,
        "employee_name": name,
        "month":         month,
        "rate":          rate,
        "bonus":         bonus,
        "total_hours":   total_hours,
        "total_salary":  total_salary,
        "days":          days_out,
    }


@router.get("/daily-detail")
async def daily_detail(
    date:        str = Query(..., description="YYYY-MM-DD"),
    employee_ids: Optional[str] = Query(None, description="ID через запятую, пусто = все"),
):
    """
    Детализация по одному дню: кто сколько отработал,
    какой источник, кто подтвердил.
    """
    d = _validate_date(date)

    async with get_conn() as (conn, cur):
        if employee_ids:
            ids = [x.strip() for x in employee_ids.split(",") if x.strip()]
            fmt = ",".join(["%s"] * len(ids))
            await cur.execute(
                f"""
                SELECT employee_id, employee_name, hours, duration_sec,
                       b24_status, source, approved_by, updated_at
                FROM `{TABLE_DAILY}`
                WHERE report_date=%s AND employee_id IN ({fmt})
                ORDER BY employee_name
                """,
                [d] + ids
            )
        else:
            await cur.execute(
                f"""
                SELECT employee_id, employee_name, hours, duration_sec,
                       b24_status, source, approved_by, updated_at
                FROM `{TABLE_DAILY}`
                WHERE report_date=%s
                ORDER BY employee_name
                """,
                (d,)
            )
        rows = await cur.fetchall()

    return [
        {
            "employee_id":   str(r["employee_id"]),
            "employee_name": r["employee_name"],
            "hours":         float(r["hours"]),
            "duration_sec":  r["duration_sec"],
            "b24_status":    r["b24_status"],
            "source":        r["source"],
            "approved_by":   r["approved_by"],
            "updated_at":    r["updated_at"].isoformat() if r["updated_at"] else None,
        }
        for r in rows
    ]
