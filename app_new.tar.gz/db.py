"""
db.py — пул соединений MySQL (aiomysql).

Изменения v2:
  - _pool экспортируется для корректного закрытия в lifespan main.py
  - добавлен close_pool() для тестов
"""

import os
import aiomysql
from contextlib import asynccontextmanager

DB_CONFIG = {
    "host":       os.getenv("DB_HOST",     ""),
    "port":       int(os.getenv("DB_PORT", "3306")),
    "user":       os.getenv("DB_USER",     ""),
    "password":   os.getenv("DB_PASSWORD", ""),
    "db":         os.getenv("DB_NAME",     ""),
    "charset":    "utf8mb4",
    "autocommit": True,
}

_pool = None


async def get_pool():
    global _pool
    if _pool is None:
        _pool = await aiomysql.create_pool(**DB_CONFIG)
    return _pool


async def close_pool():
    global _pool
    if _pool:
        _pool.close()
        await _pool.wait_closed()
        _pool = None


@asynccontextmanager
async def get_conn():
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            yield conn, cur
