"""
sync_to_sheets.py — полная копия таблицы рабочего времени в Google Sheets.
Запускается автоматически после каждого изменения БД (stop / submit).
"""

import os
import pymysql
import gspread
from datetime import datetime

DB_CONFIG = {
    "host":     os.getenv("DB_HOST",     ""),
    "port":     int(os.getenv("DB_PORT", "3306")),
    "user":     os.getenv("DB_USER",     ""),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME",     ""),
    "charset":  "utf8mb4",
}

CREDENTIALS_FILE = os.path.join(
    os.path.dirname(__file__),
    os.getenv("GOOGLE_CREDENTIALS_FILE", "google_credentials.json"),
)

SPREADSHEET_ID = os.getenv("GOOGLE_SPREADSHEET_ID", "")
SHEET_NAME     = os.getenv("GOOGLE_SHEET_NAME",     "Отчёты")
DB_TABLE       = os.getenv("DB_TABLE",              "worktime_flat")

HEADERS = [
    "ID",
    "Дата",
    "Сотрудник",
    "ID сотрудника",
    "Начало (сотрудник)",
    "Конец (сотрудник)",
    "Начало (прораб)",
    "Конец (прораб)",
    "Обед (мин)",
    "Итого (мин)",
    "Итого (часы)",
    "Прораб",
    "ID прораба",
    "Подтверждено",
]


def fmt_dt(val):
    if val is None:
        return ""
    if isinstance(val, datetime):
        return val.strftime("%H:%M")
    return str(val)


def fmt_date(val):
    if val is None:
        return ""
    return str(val)


def sync():
    conn = pymysql.connect(**DB_CONFIG, cursorclass=pymysql.cursors.DictCursor)
    try:
        with conn.cursor() as cur:
            cur.execute(f"""
                SELECT
                    id, report_date,
                    user_name, user_id,
                    raw_start, raw_end,
                    adjusted_start, adjusted_end,
                    lunch_minutes, total_minutes,
                    foreman_name, foreman_id,
                    confirmed_at
                FROM `{DB_TABLE}`
                ORDER BY report_date DESC, user_name ASC
            """)
            rows = cur.fetchall()
    finally:
        conn.close()

    gc = gspread.service_account(filename=CREDENTIALS_FILE)
    sh = gc.open_by_key(SPREADSHEET_ID)

    try:
        ws = sh.worksheet(SHEET_NAME)
    except gspread.WorksheetNotFound:
        ws = sh.add_worksheet(title=SHEET_NAME, rows=2000, cols=20)

    data = [HEADERS]
    for r in rows:
        total_hours = round(r["total_minutes"] / 60, 2) if r["total_minutes"] else 0
        confirmed   = fmt_dt(r["confirmed_at"]) if r["confirmed_at"] else "не подтверждено"
        data.append([
            r["id"],
            fmt_date(r["report_date"]),
            r["user_name"]    or "",
            r["user_id"]      or "",
            fmt_dt(r["raw_start"]),
            fmt_dt(r["raw_end"]),
            fmt_dt(r["adjusted_start"]),
            fmt_dt(r["adjusted_end"]),
            r["lunch_minutes"] or 0,
            r["total_minutes"] or 0,
            total_hours,
            r["foreman_name"] or "",
            r["foreman_id"]   or "",
            confirmed,
        ])

    ws.clear()
    ws.update("A1", data)
    ws.format("A1:N1", {"textFormat": {"bold": True}})


if __name__ == "__main__":
    sync()
