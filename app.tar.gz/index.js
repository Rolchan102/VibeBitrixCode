const express = require('express');
const app = express();
const port = 3000;

let employees = [
  { id: 318, name: "Алексей Новосельцев", rate: 500, totalHours: 56 },
  { id: 196, name: "Анжелика Дубровская", rate: 450, totalHours: 40 },
  { id: 150, name: "Дмитрий Полубояров", rate: 600, totalHours: 120 }
];

const dailyWork = { 318: 8, 196: 6, 150: 0 };

app.get('/', (req, res) => {
  let html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Учет часов и выплат</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 30px; background: #f5f7fa; }
    h1 { color: #2c3e50; }
    table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
    th { background: #3498db; color: white; font-weight: 600; }
    tr:hover { background: #f8f9fa; }
    .money { color: #27ae60; font-weight: bold; }
  </style>
</head>
<body>
  <h1>📊 Учет часов и выплат</h1>
  <table>
    <thead>
      <tr>
        <th>Сотрудник</th>
        <th>Сегодня</th>
        <th>Всего часов</th>
        <th>Итого (руб.)</th>
      </tr>
    </thead>
    <tbody>
  `;

  employees.forEach(emp => {
    const today = dailyWork[emp.id] || 0;
    const total = emp.totalHours + today;
    const money = total * emp.rate;
    
    html += `
      <tr>
        <td><b>${emp.name}</b> <span style="color:#7f8c8d;font-size:0.9em">(ID: ${emp.id})</span></td>
        <td>${today} ч.</td>
        <td><b>${total} ч.</b></td>
        <td class="money">${money.toLocaleString('ru-RU')} ₽</td>
      </tr>
    `;
  });

  html += `
    </tbody>
  </table>
</body>
</html>`;
  
  res.send(html);
});

app.listen(port, () => {
  console.log(`✅ App running on http://localhost:${port}`);
});