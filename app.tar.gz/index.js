require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const B24_WEBHOOK = process.env.B24_WEBHOOK || process.env.MCP_URL;
const DB_FILE = path.join(__dirname, 'data.json');

app.use(express.json());
app.use(express.static('public'));

// === Локальная БД (ставки и накопленные часы) ===
const readDB = () => {
    if (!fs.existsSync(DB_FILE)) return {};
    try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8')); }
    catch (e) { return {}; }
};
const writeDB = (data) => fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');

// === Вызов Битрикс24 REST API через вебхук ===
async function b24Call(method, params = {}) {
    try {
        const url = `${B24_WEBHOOK}${method}`;
        const resp = await axios.post(url, params, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 30000
        });
        return resp.data;
    } catch (e) {
        console.error(`B24 ${method} error:`, e.message);
        return null;
    }
}

// === Получение всех активных сотрудников ===
async function getActiveUsers() {
    let allUsers = [];
    let start = 0;
    while (true) {
        const result = await b24Call('user.get', {
            ACTIVE: true,
            USER_TYPE: 'employee',
            start
        });
        if (!result || !Array.isArray(result.result)) break;
        allUsers = allUsers.concat(result.result);
        if (result.next !== undefined && result.next !== null) {
            start = result.next;
        } else {
            break;
        }
    }
    return allUsers;
}

// === Получение часов за текущий день через timeman.status ===
async function getUserTodayHours(userId) {
    try {
        const result = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        if (result && result.result) {
            const ts = result.result;
            // DURATION — общая продолжительность рабочего дня в секундах
            if (ts.DURATION) {
                return Math.round(ts.DURATION / 3600 * 10) / 10;
            }
            // Если есть TIME_START — считаем от старта до сейчас
            if (ts.TIME_START && !ts.TIME_FINISH) {
                const startMs = new Date(ts.TIME_START).getTime();
                const nowMs = Date.now();
                const secs = Math.max(0, (nowMs - startMs) / 1000);
                return Math.round(secs / 3600 * 10) / 10;
            }
            if (ts.TIME_START && ts.TIME_FINISH) {
                const startMs = new Date(ts.TIME_START).getTime();
                const finishMs = new Date(ts.TIME_FINISH).getTime();
                const secs = Math.max(0, (finishMs - startMs) / 1000);
                return Math.round(secs / 3600 * 10) / 10;
            }
        }
        return 0;
    } catch (e) {
        return 0;
    }
}

// === API: Получить всех сотрудников с данными ===
app.get('/api/employees', async (req, res) => {
    const db = readDB();
    const users = await getActiveUsers();

    if (!users || users.length === 0) {
        return res.status(500).json({ error: 'Не удалось получить пользователей из Битрикс24' });
    }

    const employees = await Promise.all(users.map(async user => {
        const dbEntry = db[user.ID] || { rate: 500, accumulatedHours: 0, lastSyncDate: null };
        const todayHours = await getUserTodayHours(user.ID);

        return {
            id: user.ID,
            name: [user.NAME, user.LAST_NAME].filter(Boolean).join(' ') || 'Без имени',
            email: user.EMAIL || '',
            position: user.WORK_POSITION || '',
            department: Array.isArray(user.UF_DEPARTMENT) ? user.UF_DEPARTMENT[0] : null,
            rate: dbEntry.rate,
            todayHours,
            accumulatedHours: dbEntry.accumulatedHours || 0,
            totalHours: (dbEntry.accumulatedHours || 0) + todayHours,
            totalMoney: ((dbEntry.accumulatedHours || 0) + todayHours) * dbEntry.rate,
            lastSyncDate: dbEntry.lastSyncDate || null
        };
    }));

    res.json(employees);
});

// === API: Обновить ставку сотрудника ===
app.post('/api/rate', (req, res) => {
    const { employeeId, rate } = req.body;
    if (!employeeId || rate === undefined) {
        return res.status(400).json({ error: 'Требуется employeeId и rate' });
    }
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { accumulatedHours: 0, rate: 500 };
    db[employeeId].rate = parseFloat(rate);
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, newRate: db[employeeId].rate });
});

// === API: Зафиксировать (сохранить) часы сегодняшнего дня в накопленный итог ===
app.post('/api/commit-hours', async (req, res) => {
    const { employeeId } = req.body;
    if (!employeeId) return res.status(400).json({ error: 'Требуется employeeId' });

    const todayHours = await getUserTodayHours(employeeId);
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, accumulatedHours: 0 };

    const today = new Date().toISOString().split('T')[0];
    // Не дублируем часы за один день
    if (db[employeeId].lastSyncDate !== today) {
        db[employeeId].accumulatedHours = (db[employeeId].accumulatedHours || 0) + todayHours;
        db[employeeId].lastSyncDate = today;
    }
    writeDB(db);
    res.json({ success: true, accumulatedHours: db[employeeId].accumulatedHours, addedHours: todayHours });
});

// === API: Зафиксировать часы для всех сотрудников ===
app.post('/api/commit-all', async (req, res) => {
    const users = await getActiveUsers();
    if (!users) return res.status(500).json({ error: 'Не удалось получить пользователей' });

    const db = readDB();
    const today = new Date().toISOString().split('T')[0];
    let updated = 0;

    for (const user of users) {
        if (!db[user.ID]) db[user.ID] = { rate: 500, accumulatedHours: 0, lastSyncDate: null };
        if (db[user.ID].lastSyncDate !== today) {
            const todayHours = await getUserTodayHours(user.ID);
            if (todayHours > 0) {
                db[user.ID].accumulatedHours = (db[user.ID].accumulatedHours || 0) + todayHours;
                db[user.ID].lastSyncDate = today;
                updated++;
            }
        }
    }
    writeDB(db);
    res.json({ success: true, updatedCount: updated });
});

// === API: Вручную скорректировать накопленные часы ===
app.post('/api/adjust-hours', (req, res) => {
    const { employeeId, hours } = req.body;
    if (!employeeId || hours === undefined) {
        return res.status(400).json({ error: 'Требуется employeeId и hours' });
    }
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, accumulatedHours: 0 };
    db[employeeId].accumulatedHours = Math.max(0, parseFloat(hours));
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, newAccumulatedHours: db[employeeId].accumulatedHours });
});

// === Фронтенд ===
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`✅ b24-payroll v1.2.0 running on port ${PORT}`);
    console.log(`🔗 B24 Webhook: ${B24_WEBHOOK}`);
});