require('dotenv').config();
const { calculateWorkedHours } = require('./utils/time_calc');
console.log('=== ENV CHECK ===');
console.log('B24_WEBHOOK:', process.env.B24_WEBHOOK);
console.log('PORT:', process.env.PORT);
console.log('================');

const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const { saveDailyHours, readMonthData, writeMonthData, getLastKnownRate } = require('./save_daily_hours');

const app = express();
const PORT = process.env.PORT || 3000;
const B24_WEBHOOK = process.env.B24_WEBHOOK || process.env.MCP_URL;

// ==========================================
// УТИЛИТЫ
// ==========================================
const readJSON = (file, fallback = {}) => {
    if (!fs.existsSync(file)) return fallback;
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch (e) { console.error('Ошибка чтения JSON:', e.message); return fallback; }
};
const writeJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
};

// ==========================================
// Express middleware
// ==========================================
app.use(express.json());


// ==========================================
// Обёртка для вызова Bitrix24 REST API
// ==========================================
async function b24Call(method, params = {}) {
    try {
        const url = new URL(`${B24_WEBHOOK}${method}`);
        Object.entries(params).forEach(([key, value]) => {
            if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
                url.searchParams.append(key, JSON.stringify(value));
            } else {
                url.searchParams.append(key, String(value));
            }
        });
        const resp = await axios.get(url.toString(), { timeout: 30000 });
        const data = resp.data;
        if (data?.error) {
            console.error(`B24 ${method}:`, data.error_description || data.error);
            return null;
        }
        return data;
    } catch (e) {
        console.error(`B24 ${method} network error:`, e.message);
        return null;
    }
}

// ==========================================
// Получение списка активных сотрудников
// ==========================================
async function getActiveUsers() {
    let allUsers = [], start = 0;
    while (true) {
        const params = {
            ACTIVE: true, USER_TYPE: "employee", SORT: "ID", ORDER: "asc",
            SELECT: ["ID", "NAME", "LAST_NAME", "EMAIL", "WORK_POSITION", "UF_DEPARTMENT"],
            start
        };
        const result = await b24Call('user.get', params);
        if (!result?.result || !Array.isArray(result.result)) break;
        allUsers = allUsers.concat(result.result);
        if (typeof result.next === 'number') start = result.next; else break;
    }
    console.log(`Загружено сотрудников: ${allUsers.length}`);
    return allUsers;
}

// ==========================================
// API Эндпоинты
// ==========================================

/**
 * Получает актуальные часы сотрудника за сегодня из timeman.status.
 * Не сохраняет в файл — только для отображения.
 */
async function getLiveHours(userId) {
    try {
        const result = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        const calc = calculateWorkedHours(result?.result);
        return calc.hours;
    } catch (e) {
        console.error(`getLiveHours error (user ${userId}):`, e.message);
        return null;
    }
}

/**
 * Собирает отчёт из файла + опционально живых данных за сегодня.
 * @param {string} month         — "2026-05"
 * @param {Object} liveToday     — { userId: hours } или {} для чтения только из файла
 */
async function buildReport(month, liveToday = {}) {
    const [year, mon] = month.split('-').map(Number);
    const daysInMonth = new Date(year, mon, 0).getDate();
    const todayStr = new Date().toISOString().split('T')[0];

    const monthData = readMonthData(month);
    const users = await getActiveUsers();

    // Гарантируем запись в meta для каждого сотрудника
    let metaChanged = false;
    for (const user of users) {
        if (!monthData.meta.employees[user.ID]) {
            monthData.meta.employees[user.ID] = {
                name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                rate: getLastKnownRate(user.ID, month),
                bonus: 0
            };
            metaChanged = true;
        }
    }
    if (metaChanged) writeMonthData(month, monthData);

    return users.map(user => {
        const empMeta = monthData.meta.employees[user.ID] || { rate: 500, bonus: 0 };
        const dailyHours = {};
        let totalHours = 0;

        for (let d = 1; d <= daysInMonth; d++) {
            const dateStr = `${month}-${String(d).padStart(2, '0')}`;
            let h = monthData.days[dateStr]?.[user.ID]?.hours || 0;

            // Живые данные за сегодня имеют приоритет, если день не зафиксирован вручную
            if (dateStr === todayStr && liveToday[user.ID] !== undefined) {
                const savedStatus = monthData.days[dateStr]?.[user.ID]?.status;
                const isManuallyFixed = savedStatus === 'committed' || savedStatus === 'overridden';
                if (!isManuallyFixed) h = liveToday[user.ID];
            }

            dailyHours[dateStr] = h;
            totalHours += h;
        }

        totalHours = Math.round(totalHours * 100) / 100;
        const rate = empMeta.rate ?? 500;
        const bonus = empMeta.bonus ?? 0;

        return {
            id: user.ID,
            name: [user.NAME, user.LAST_NAME].filter(Boolean).join(' ') || 'Без имени',
            position: user.WORK_POSITION || '',
            rate, bonus, dailyHours, totalHours,
            totalMoney: Math.round(totalHours * rate) + bonus
        };
    });
}

/**
 * Опрашивает timeman.status для всех пользователей, возвращает { userId: hours }.
 * Задержка 600мс между запросами (лимит Bitrix24 ~2 req/sec).
 */
async function fetchLiveToday(users) {
    const liveToday = {};
    console.log(`[live] Опрашиваем timeman.status для ${users.length} сотрудников...`);
    for (const user of users) {
        await new Promise(r => setTimeout(r, 600));
        const h = await getLiveHours(user.ID);
        if (h !== null) liveToday[user.ID] = h;
    }
    console.log(`[live] Получено: ${Object.keys(liveToday).length} сотрудников`);
    return liveToday;
}

/**
 * GET /api/monthly-report?month=2026-05
 * Читает только сохранённый файл — быстро, без запросов в Bitrix24.
 */
app.get('/api/monthly-report', async (req, res) => {
    try {
        const { month } = req.query;
        if (!month || !/^\d{4}-\d{2}$/.test(month)) {
            return res.status(400).json({ error: 'Требуется параметр month в формате YYYY-MM' });
        }
        const report = await buildReport(month, {});
        res.json(report);
    } catch (e) {
        console.error('/api/monthly-report error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

/**
 * GET /api/refresh-today?month=2026-05
 * Подтягивает живые часы за сегодня из timeman.status — для кнопки «🔄 Обновить».
 * Только текущий месяц; данные НЕ сохраняются в файл.
 */
app.get('/api/refresh-today', async (req, res) => {
    try {
        const { month } = req.query;
        if (!month || !/^\d{4}-\d{2}$/.test(month)) {
            return res.status(400).json({ error: 'Требуется параметр month в формате YYYY-MM' });
        }
        const todayMonth = new Date().toISOString().slice(0, 7);
        if (month !== todayMonth) {
            return res.status(400).json({ error: 'Обновление доступно только для текущего месяца' });
        }

        const users = await getActiveUsers();
        const liveToday = await fetchLiveToday(users);
        const report = await buildReport(month, liveToday);
        res.json(report);
    } catch (e) {
        console.error('/api/refresh-today error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

/**
 * POST /api/commit-today
 * Фиксирует живые часы за сегодня в файл — для кнопки «✅ Зафиксировать день».
 * Крон в 23:30 делает то же самое через saveDailyHours(), но перезаписывает auto_saved.
 */
app.post('/api/commit-today', async (req, res) => {
    try {
        const todayStr = new Date().toISOString().split('T')[0];
        const month = todayStr.slice(0, 7);
        const users = await getActiveUsers();

        if (!users.length) return res.status(500).json({ error: 'Не удалось получить сотрудников' });

        const monthData = readMonthData(month);
        if (!monthData.days[todayStr]) monthData.days[todayStr] = {};

        let saved = 0;
        for (const user of users) {
            await new Promise(r => setTimeout(r, 600));
            const result = await b24Call('timeman.status', { USER_ID: parseInt(user.ID) });
            const calc = calculateWorkedHours(result?.result);
            const h = Math.round(calc.hours * 100) / 100;

            if (h >= 0.01 || calc.status === 'closed') {
                monthData.days[todayStr][user.ID] = {
                    hours: h,
                    duration_sec: Math.round(calc.durationSec || 0),
                    status: 'committed',
                    name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                    committedAt: new Date().toISOString(),
                    b24Status: calc.status
                };
                saved++;
            }

            // Инициализируем meta если нет
            if (!monthData.meta.employees[user.ID]) {
                monthData.meta.employees[user.ID] = {
                    name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                    rate: getLastKnownRate(user.ID, month),
                    bonus: 0
                };
            }
        }

        writeMonthData(month, monthData);
        console.log(`[commit-today] Зафиксировано ${saved} записей за ${todayStr}`);
        res.json({ success: true, date: todayStr, saved });
    } catch (e) {
        console.error('/api/commit-today error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

/**
 * POST /api/rate
 * Устанавливает ставку сотрудника для конкретного месяца.
 * Body: { employeeId, rate, month }
 */
app.post('/api/rate', (req, res) => {
    const { employeeId, rate, month } = req.body;
    if (!employeeId || rate === undefined || !month) {
        return res.status(400).json({ error: 'employeeId, rate и month обязательны' });
    }
    const empId = String(employeeId);
    const monthData = readMonthData(month);
    if (!monthData.meta.employees[empId]) {
        monthData.meta.employees[empId] = { rate: 500, bonus: 0 };
    }
    monthData.meta.employees[empId].rate = parseFloat(rate);
    monthData.meta.employees[empId].lastUpdated = new Date().toISOString();
    writeMonthData(month, monthData);
    res.json({ success: true, month, newRate: monthData.meta.employees[empId].rate });
});

/**
 * POST /api/bonus
 * Устанавливает премию сотрудника для конкретного месяца.
 * Body: { employeeId, bonus, month }
 */
app.post('/api/bonus', (req, res) => {
    const { employeeId, bonus, month } = req.body;
    if (!employeeId || bonus === undefined || !month) {
        return res.status(400).json({ error: 'employeeId, bonus и month обязательны' });
    }
    const empId = String(employeeId);
    const monthData = readMonthData(month);
    if (!monthData.meta.employees[empId]) {
        monthData.meta.employees[empId] = { rate: 500, bonus: 0 };
    }
    monthData.meta.employees[empId].bonus = Math.max(0, parseFloat(bonus));
    monthData.meta.employees[empId].lastUpdated = new Date().toISOString();
    writeMonthData(month, monthData);
    res.json({ success: true, month, newBonus: monthData.meta.employees[empId].bonus });
});

/**
 * POST /api/adjust-daily
 * Корректирует часы конкретного дня вручную.
 * Body: { employeeId, date, hours }
 */
app.post('/api/adjust-daily', (req, res) => {
    const { employeeId, date, hours } = req.body;
    if (!employeeId || !date || hours === undefined) {
        return res.status(400).json({ error: 'employeeId, date и hours обязательны' });
    }

    const month = date.slice(0, 7);
    const monthData = readMonthData(month);

    if (!monthData.days[date]) monthData.days[date] = {};
    monthData.days[date][employeeId] = {
        ...(monthData.days[date][employeeId] || {}),
        hours: Math.max(0, parseFloat(hours)),
        status: 'overridden',
        overridden: true,
        lastModified: new Date().toISOString()
    };

    writeMonthData(month, monthData);
    res.json({ success: true, date, newHours: monthData.days[date][employeeId].hours });
});



// ==========================================
// Авто-сохранение часов в 23:30 по Москве
// ==========================================
cron.schedule('30 23 * * *', async () => {
    console.log('[CRON] Авто-сохранение часов...');
    try {
        await saveDailyHours();
        console.log('[CRON] Готово');
    } catch (e) {
        console.error('[CRON] Ошибка:', e.message);
    }
}, { timezone: 'Europe/Moscow' });



// ==========================================
// Статика, диагностика и обработка 404
// ==========================================

// Диагностика — проверяет что Express жив и роуты работают
app.get('/api/ping', (req, res) => {
    res.json({ ok: true, ts: new Date().toISOString() });
});

// static ПОСЛЕ /api/* — иначе папка public может перехватить запросы
app.use(express.static('public'));

// Фронтенд SPA fallback
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Неизвестные /api/* — отдаём JSON, не HTML
app.use('/api', (req, res) => {
    res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` });
});

// ==========================================
// Запуск
// ==========================================
app.listen(PORT, () => {
    console.log(`b24-payroll v2.0 ready on port ${PORT}`);
    console.log(`Webhook: ${B24_WEBHOOK}`);
});