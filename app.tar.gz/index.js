require('dotenv').config();
const { getHoursOnly, calculateWorkedHours } = require('./utils/time_calc');
console.log('=== ENV CHECK ===');
console.log('B24_WEBHOOK:', process.env.B24_WEBHOOK);
console.log('MCP_URL:', process.env.MCP_URL);
console.log('PORT:', process.env.PORT);
console.log('================');
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const { saveDailyHours } = require('./save_daily_hours');

const app = express();
const PORT = process.env.PORT || 3000;
const B24_WEBHOOK = process.env.B24_WEBHOOK || process.env.MCP_URL;
const DB_FILE = path.join(__dirname, 'data.json');

app.use(express.json());
app.use(express.static('public'));

// ==========================================
// Локальная БД (ставки и накопленные часы)
// ==========================================
// Объявляем ПЕРЕД использованием в роутах
const readDB = () => {
    if (!fs.existsSync(DB_FILE)) return {};
    try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8')); }
    catch (e) { console.error('Ошибка чтения data.json:', e.message); return {}; }
};

const writeDB = (data) => {
    try { fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8'); }
    catch (e) { console.error('Ошибка записи data.json:', e.message); }
};

// ==========================================
// Обёртка для вызова Bitrix24 REST API
// ==========================================
async function b24Call(method, params = {}) {
    try {
        const url = new URL(`${B24_WEBHOOK}${method}`);
        Object.entries(params).forEach(([key, value]) => {
            if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
                url.searchParams.append(key, JSON.stringify(value));
            } else {
                url.searchParams.append(key, String(value));
            }
        });
        const resp = await axios.get(url.toString(), { timeout: 30000 });
        const data = resp.data;
        if (data?.error) {
            console.error(`B24 ${method}:`, data.error_description || data.error);
            return null;
        }
        return data;
    } catch (e) {
        console.error(`B24 ${method} network error:`, e.message);
        return null;
    }
}

// ==========================================
// Получение списка активных сотрудников
// ==========================================
async function getActiveUsers() {
    let allUsers = [], start = 0;
    while (true) {
        const params = {
            ACTIVE: true, USER_TYPE: "employee", SORT: "ID", ORDER: "asc",
            SELECT: ["ID", "NAME", "LAST_NAME", "EMAIL", "WORK_POSITION", "UF_DEPARTMENT"],
            start: start
        };
        const result = await b24Call('user.get', params);
        if (!result?.result || !Array.isArray(result.result)) break;
        allUsers = allUsers.concat(result.result);
        if (typeof result.next === 'number') start = result.next; else break;
    }
    console.log(`Загружено сотрудников: ${allUsers.length}`);
    return allUsers;
}

// ==========================================
// Расчёт отработанных часов за СЕГОДНЯ (с учётом перерывов)
// ==========================================
async function getTodayHours(userId) {
    try {
        const result = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        // Возвращаем только число часов — для совместимости с существующим кодом
        return getHoursOnly(result?.result);
    } catch (e) {
        console.error(`timeman.status error (user ${userId}):`, e.message);
        return 0;
    }
}

// ==========================================
// API Эндпоинты
// ==========================================

// /api/adjust — теперь после readDB/writeDB
app.post('/api/adjust', (req, res) => {
    const { employeeId, field, value } = req.body;
    
    // Нормализация ID (на всякий случай)
    const empId = String(employeeId);
    
    if (!empId || !field || value === undefined) {
        return res.status(400).json({ error: 'employeeId, field и value обязательны' });
    }
    
    const db = readDB();
    if (!db[empId]) db[empId] = { rate: 500, accumulatedHours: 0, bonus: 0 };
    
    if (field === 'accumulatedHours') {
        db[empId].accumulatedHours = Math.max(0, parseFloat(value));
        db[empId].accumulatedHoursOverridden = true;  // ← НОВЫЙ ФЛАГ
        db[empId].lastUpdated = new Date().toISOString();
    } else if (field === 'bonus') {
        db[empId].bonus = Math.max(0, parseFloat(value));
    } else {
        return res.status(400).json({ error: 'Неверное поле для корректировки' });
    }
    
    db[empId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, field, newValue: db[empId][field] });
});

// GET /api/employees — с расчётом накопленных часов из all_hours.json
app.get('/api/employees', async (req, res) => {
    try {
        const db = readDB();
        const users = await getActiveUsers();
        if (!users?.length) return res.status(500).json({ error: 'Не удалось получить пользователей' });
        
        // Определяем текущий месяц для фильтрации истории
        const currentMonth = new Date().toISOString().slice(0, 7); // "2026-05"
        
        const employees = await Promise.all(users.map(async user => {
            const entry = db[user.ID] || { rate: 500, bonus: 0 };
            
            // Накопленные часы считаем из all_hours.json за текущий месяц
            const accumulatedHours = entry.accumulatedHoursOverridden 
                ? entry.accumulatedHours 
                : recalcAccumulatedHours(user.ID, currentMonth);
            
            const today = await getTodayHours(user.ID);
            const rate = entry.rate || 500;
            const total = accumulatedHours + today;
            const bonus = entry.bonus || 0;
            const totalMoney = Math.round(total * rate) + bonus;
            
            return {
                id: user.ID,
                name: [user.NAME, user.LAST_NAME].filter(Boolean).join(' ') || 'Без имени',
                email: user.EMAIL || '',
                position: user.WORK_POSITION || '',
                department: Array.isArray(user.UF_DEPARTMENT) ? user.UF_DEPARTMENT[0] : null,
                rate,
                todayHours: +today.toFixed(2),
                accumulatedHours,  // из истории
                totalHours: +total.toFixed(2),
                bonus,
                totalMoney,
                lastSyncDate: entry.lastSyncDate || null
            };
        }));
        res.json(employees);
    } catch (e) {
        console.error('/api/employees error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

// ==========================================
// GET /api/monthly-report?month=2025-02
// ==========================================
const HISTORY_FILE = path.join(__dirname, 'all_hours.json');

// Вспомогательная функция для чтения JSON (если нет readJSON в scope)
const readJSON = (file, fallback = {}) => {
    if (!fs.existsSync(file)) return fallback;
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return fallback; }
};
const writeJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
};

// ==========================================
// Пересчёт accumulatedHours из all_hours.json
// ==========================================
function recalcAccumulatedHours(employeeId, month = null) {
    const history = readJSON(HISTORY_FILE, {});
    let total = 0;
    
    for (const [date, employees] of Object.entries(history)) {
        // Если указан месяц — фильтруем по нему
        if (month && !date.startsWith(month)) continue;
        
        if (employees[employeeId]?.hours) {
            total += employees[employeeId].hours;
        }
    }
    
    return Math.round(total * 100) / 100;
}

app.get('/api/monthly-report', async (req, res) => {
    try {
        const { month } = req.query; // формат YYYY-MM
        if (!month) return res.status(400).json({ error: 'Требуется параметр month' });
        
        const [year, mon] = month.split('-').map(Number);
        const daysInMonth = new Date(year, mon, 0).getDate();
        
        // Используем readJSON для истории и readDB для ставок
        const history = readJSON(HISTORY_FILE, {});
        const db = readDB(); // ← используем существующую функцию
        const users = await getActiveUsers();
        
        const report = users.map(user => {
            const empData = db[user.ID] || { rate: 500, bonus: 0 };
            const dailyHours = {};
            let totalHours = 0;
            
            for (let d = 1; d <= daysInMonth; d++) {
                const dateStr = `${month}-${String(d).padStart(2, '0')}`;
                const dayData = history[dateStr]?.[user.ID];
                const h = dayData ? dayData.hours : 0;
                dailyHours[dateStr] = h;
                totalHours += h;
            }
            
            return {
                id: user.ID,
                name: [user.NAME, user.LAST_NAME].filter(Boolean).join(' ') || 'Без имени',
                position: user.WORK_POSITION || '',
                rate: empData.rate,
                bonus: empData.bonus,
                dailyHours,
                totalHours: Math.round(totalHours * 100) / 100,
                totalMoney: Math.round(totalHours * empData.rate) + empData.bonus
            };
        });
        
        res.json(report);
    } catch (e) {
        console.error('/api/monthly-report error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

// POST /api/rate — Обновить ставку
app.post('/api/rate', (req, res) => {
    const { employeeId, rate } = req.body;
    if (!employeeId || rate === undefined) return res.status(400).json({ error: 'employeeId и rate обязательны' });
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { accumulatedHours: 0, rate: 500 };
    db[employeeId].rate = parseFloat(rate);
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, newRate: db[employeeId].rate });
});

// POST /api/commit-hours — Фиксация одного сотрудника с записью в историю
app.post('/api/commit-hours', async (req, res) => {
    const { employeeId } = req.body;
    if (!employeeId) return res.status(400).json({ error: 'employeeId обязателен' });
    
    const today = await getTodayHours(employeeId);
    if (today <= 0) return res.json({ success: true, message: 'Нет часов для фиксации', accumulatedHours: 0 });
    
    const db = readDB();
    const history = readJSON(HISTORY_FILE, {});
    const dateStr = new Date().toISOString().split('T')[0];
    
    if (!db[employeeId]) db[employeeId] = { rate: 500, accumulatedHours: 0, bonus: 0 };
    
    // Фиксируем только если ещё не фиксировали сегодня
    if (db[employeeId].lastSyncDate !== dateStr) {
        // 1. Обновляем кэш в data.json
        if (!db[employeeId].accumulatedHoursOverridden) {
            db[employeeId].accumulatedHours = recalcAccumulatedHours(employeeId) + today;
        }
        db[employeeId].lastSyncDate = dateStr;
        
        // 2. Записываем в all_hours.json (история)
        if (!history[dateStr]) history[dateStr] = {};
        
        // Получаем имя сотрудника
        const user = await b24Call('user.get', { 
            ID: parseInt(employeeId), 
            SELECT: ['NAME', 'LAST_NAME'] 
        });
        const userName = user?.result?.[0] 
            ? `${user.result[0].NAME} ${user.result[0].LAST_NAME}`.trim() 
            : 'Unknown';
        
        history[dateStr][employeeId] = {
            hours: Math.round(today * 100) / 100,
            duration_sec: Math.round(today * 3600),
            status: 'committed',
            name: userName,
            committedAt: new Date().toISOString()
        };
        
        // Сохраняем оба файла
        writeDB(db);
        writeJSON(HISTORY_FILE, history);
        
        console.log(`[commit-hours] User ${employeeId}: +${today.toFixed(2)} ч за ${dateStr}`);
    }
    
    res.json({ 
        success: true, 
        accumulatedHours: db[employeeId].accumulatedHours, 
        addedHours: today 
    });
});

// POST /api/commit-all — Массовая фиксация с записью в историю
app.post('/api/commit-all', async (req, res) => {
    const users = await getActiveUsers();
    if (!users?.length) return res.status(500).json({ error: 'Не удалось получить пользователей' });
    
    const db = readDB();
    const history = readJSON(HISTORY_FILE, {});
    const dateStr = new Date().toISOString().split('T')[0];
    
    // Инициализируем дату в истории, если нет
    if (!history[dateStr]) history[dateStr] = {};
    
    let updated = 0;
    
    for (const user of users) {
        if (!db[user.ID]) db[user.ID] = { rate: 500, accumulatedHours: 0, bonus: 0 };
        
        // Фиксируем только если ещё не фиксировали сегодня
        if (db[user.ID].lastSyncDate !== dateStr) {
            const h = await getTodayHours(user.ID);
            if (h > 0) {
                // 1. Обновляем data.json (кэш)
                if (!db[user.ID].accumulatedHoursOverridden) {
                    db[user.ID].accumulatedHours = recalcAccumulatedHours(user.ID) + h;
                }
                db[user.ID].lastSyncDate = dateStr;
                
                // 2. Записываем в all_hours.json (история по дням)
                history[dateStr][user.ID] = {
                    hours: Math.round(h * 100) / 100,
                    duration_sec: Math.round(h * 3600),
                    status: 'committed',
                    name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                    committedAt: new Date().toISOString()
                };
                
                updated++;
                console.log(`[commit] User ${user.ID}: +${h.toFixed(2)} ч за ${dateStr}`);
            }
        }
    }
    
    // Сохраняем оба файла
    writeDB(db);
    writeJSON(HISTORY_FILE, history);
    
    console.log(`[commit-all] Обновлено: ${updated} записей`);
    res.json({ success: true, updatedCount: updated, date: dateStr });
});

// === ЭНДПОИНТ: корректировка часов за конкретный день ===
app.post('/api/adjust-daily', (req, res) => {
    const { employeeId, date, hours } = req.body;
    if (!employeeId || !date || hours === undefined) {
        return res.status(400).json({ error: 'employeeId, date и hours обязательны' });
    }
    
    const history = readJSON(HISTORY_FILE, {});
    if (!history[date]) history[date] = {};
    
    // Сохраняем перезаписанное значение
    history[date][employeeId] = {
        ...(history[date][employeeId] || {}),
        hours: Math.max(0, parseFloat(hours)),
        overridden: true,
        lastModified: new Date().toISOString()
    };
    
    writeJSON(HISTORY_FILE, history);

    // Пересчитываем accumulatedHours для этого сотрудника
    const db = readDB();
    if (db[employeeId]) {
        const currentMonth = new Date().toISOString().slice(0, 7);
        db[employeeId].accumulatedHours = recalcAccumulatedHours(employeeId, currentMonth);
        db[employeeId].lastUpdated = new Date().toISOString();
        writeDB(db);
    }

    res.json({ 
        success: true, 
        date, 
        newHours: history[date][employeeId].hours,
        newAccumulated: db[employeeId]?.accumulatedHours 
    });
});

// Фронтенд
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Авто-сохранение в 23:30 МСК
cron.schedule('30 23 * * *', async () => {
    console.log('[CRON] Авто-сохранение часов...');
    try {
        await saveDailyHours();
        console.log('[CRON] Готово');
    } catch (e) {
        console.error('[CRON] Ошибка:', e.message);
    }
}, { timezone: 'Europe/Moscow' });

// Запуск
app.listen(PORT, () => {
    console.log(`b24-payroll v2.0 ready on port ${PORT}`);
    console.log(`Webhook: ${B24_WEBHOOK}`);
    console.log(`Database: ${DB_FILE}`);
});