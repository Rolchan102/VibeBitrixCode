require('dotenv').config();
console.log('=== ENV CHECK ===');
console.log('B24_WEBHOOK:', process.env.B24_WEBHOOK);
console.log('MCP_URL:', process.env.MCP_URL);
console.log('PORT:', process.env.PORT);
console.log('================');
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const { saveDailyHours } = require('./save_daily_hours');

const app = express();
const PORT = process.env.PORT || 3000;
const B24_WEBHOOK = process.env.B24_WEBHOOK || process.env.MCP_URL;
const DB_FILE = path.join(__dirname, 'data.json');

app.use(express.json());
app.use(express.static('public'));

// ==========================================
// Локальная БД (ставки и накопленные часы)
// ==========================================
// Объявляем ПЕРЕД использованием в роутах
const readDB = () => {
    if (!fs.existsSync(DB_FILE)) return {};
    try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8')); }
    catch (e) { console.error('Ошибка чтения data.json:', e.message); return {}; }
};

const writeDB = (data) => {
    try { fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8'); }
    catch (e) { console.error('Ошибка записи data.json:', e.message); }
};

// ==========================================
// Обёртка для вызова Bitrix24 REST API
// ==========================================
async function b24Call(method, params = {}) {
    try {
        const url = new URL(`${B24_WEBHOOK}${method}`);
        Object.entries(params).forEach(([key, value]) => {
            if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
                url.searchParams.append(key, JSON.stringify(value));
            } else {
                url.searchParams.append(key, String(value));
            }
        });
        const resp = await axios.get(url.toString(), { timeout: 30000 });
        const data = resp.data;
        if (data?.error) {
            console.error(`B24 ${method}:`, data.error_description || data.error);
            return null;
        }
        return data;
    } catch (e) {
        console.error(`B24 ${method} network error:`, e.message);
        return null;
    }
}

// ==========================================
// Получение списка активных сотрудников
// ==========================================
async function getActiveUsers() {
    let allUsers = [], start = 0;
    while (true) {
        const params = {
            ACTIVE: true, USER_TYPE: "employee", SORT: "ID", ORDER: "asc",
            SELECT: ["ID", "NAME", "LAST_NAME", "EMAIL", "WORK_POSITION", "UF_DEPARTMENT"],
            start: start
        };
        const result = await b24Call('user.get', params);
        if (!result?.result || !Array.isArray(result.result)) break;
        allUsers = allUsers.concat(result.result);
        if (typeof result.next === 'number') start = result.next; else break;
    }
    console.log(`Загружено сотрудников: ${allUsers.length}`);
    return allUsers;
}

// ==========================================
// Расчёт отработанных часов за СЕГОДНЯ (с учётом перерывов)
// ==========================================
async function getTodayHours(userId) {
    try {
        const result = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        const ts = result?.result;
        if (!ts) return 0;

        // Если день закрыт — считаем полное время присутствия (включая перерывы)
        if (ts.STATUS === 'CLOSED' && ts.TIME_START && ts.TIME_FINISH) {
            const start = new Date(ts.TIME_START).getTime();
            const finish = new Date(ts.TIME_FINISH).getTime();
            const secs = (finish - start) / 1000;
            return Math.max(0, secs) / 3600;
        }

        // Если есть готовый DURATION (в секундах или строке "HH:MM:SS")
        if (ts.DURATION) {
            let secs = 0;
            if (typeof ts.DURATION === 'number') {
                secs = ts.DURATION;
            } else if (typeof ts.DURATION === 'string') {
                // Парсим строку "08:00:00" → секунды
                const parts = ts.DURATION.split(':').map(Number);
                secs = parts[0] * 3600 + parts[1] * 60 + (parts[2] || 0);
            }
            // Добавляем перерывы, если они есть
            if (ts.TIME_LEAKS && typeof ts.TIME_LEAKS === 'string') {
                const leakParts = ts.TIME_LEAKS.split(':').map(Number);
                const leakSecs = leakParts[0] * 3600 + leakParts[1] * 60 + (leakParts[2] || 0);
                secs += leakSecs;
            }
            return secs / 3600;
        }

        // Если день ещё открыт — считаем от TIME_START до сейчас
        if (ts.TIME_START && !ts.TIME_FINISH) {
            const secs = (Date.now() - new Date(ts.TIME_START).getTime()) / 1000;
            return Math.max(0, secs) / 3600;
        }

        return 0;
    } catch (e) {
        console.error(`timeman.status error (user ${userId}):`, e.message);
        return 0;
    }
}

// ==========================================
// API Эндпоинты
// ==========================================

// /api/adjust — теперь после readDB/writeDB
app.post('/api/adjust', (req, res) => {
    const { employeeId, field, value } = req.body;
    if (!employeeId || !field || value === undefined) {
        return res.status(400).json({ error: 'employeeId, field и value обязательны' });
    }
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, accumulatedHours: 0, bonus: 0 };
    
    if (field === 'accumulatedHours') {
        db[employeeId].accumulatedHours = Math.max(0, parseFloat(value));
    } else if (field === 'bonus') {
        db[employeeId].bonus = Math.max(0, parseFloat(value));
    } else {
        return res.status(400).json({ error: 'Неверное поле для корректировки' });
    }
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, field, newValue: db[employeeId][field] });
});

// GET /api/employees — с учётом премии
app.get('/api/employees', async (req, res) => {
    try {
        const db = readDB();
        const users = await getActiveUsers();
        if (!users?.length) return res.status(500).json({ error: 'Не удалось получить пользователей' });
        const employees = await Promise.all(users.map(async user => {
            const entry = db[user.ID] || { rate: 500, accumulatedHours: 0, bonus: 0, lastSyncDate: null };
            const today = await getTodayHours(user.ID);
            const accum = entry.accumulatedHours || 0;
            const rate = entry.rate || 500;
            const total = accum + today;
            const bonus = entry.bonus || 0;
            const totalMoney = Math.round(total * rate) + bonus;  // ← премия добавляется
            return {
                id: user.ID,
                name: [user.NAME, user.LAST_NAME].filter(Boolean).join(' ') || 'Без имени',
                email: user.EMAIL || '',
                position: user.WORK_POSITION || '',
                department: Array.isArray(user.UF_DEPARTMENT) ? user.UF_DEPARTMENT[0] : null,
                rate,
                todayHours: +today.toFixed(2),
                accumulatedHours: +accum.toFixed(2),
                totalHours: +total.toFixed(2),
                bonus,  // ← возвращаем премию
                totalMoney,  // ← уже с премией
                lastSyncDate: entry.lastSyncDate || null
            };
        }));
        res.json(employees);
    } catch (e) {
        console.error('/api/employees error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

// ==========================================
// GET /api/monthly-report?month=2025-02
// ==========================================
const HISTORY_FILE = path.join(__dirname, 'all_hours.json'); // ← ДОБАВИТЬ ЭТУ СТРОКУ

// Вспомогательная функция для чтения JSON (если нет readJSON в scope)
const readJSON = (file, fallback = {}) => {
    if (!fs.existsSync(file)) return fallback;
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return fallback; }
};

app.get('/api/monthly-report', async (req, res) => {
    try {
        const { month } = req.query; // формат YYYY-MM
        if (!month) return res.status(400).json({ error: 'Требуется параметр month' });
        
        const [year, mon] = month.split('-').map(Number);
        const daysInMonth = new Date(year, mon, 0).getDate();
        
        // Используем readJSON для истории и readDB для ставок
        const history = readJSON(HISTORY_FILE, {});
        const db = readDB(); // ← используем существующую функцию
        const users = await getActiveUsers();
        
        const report = users.map(user => {
            const empData = db[user.ID] || { rate: 500, bonus: 0 };
            const dailyHours = {};
            let totalHours = 0;
            
            for (let d = 1; d <= daysInMonth; d++) {
                const dateStr = `${month}-${String(d).padStart(2, '0')}`;
                const dayData = history[dateStr]?.[user.ID];
                const h = dayData ? dayData.hours : 0;
                dailyHours[dateStr] = h;
                totalHours += h;
            }
            
            return {
                id: user.ID,
                name: [user.NAME, user.LAST_NAME].filter(Boolean).join(' ') || 'Без имени',
                position: user.WORK_POSITION || '',
                rate: empData.rate,
                bonus: empData.bonus,
                dailyHours,
                totalHours: Math.round(totalHours * 100) / 100,
                totalMoney: Math.round(totalHours * empData.rate) + empData.bonus
            };
        });
        
        res.json(report);
    } catch (e) {
        console.error('/api/monthly-report error:', e);
        res.status(500).json({ error: 'Internal server error', details: e.message });
    }
});

// POST /api/rate — Обновить ставку
app.post('/api/rate', (req, res) => {
    const { employeeId, rate } = req.body;
    if (!employeeId || rate === undefined) return res.status(400).json({ error: 'employeeId и rate обязательны' });
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { accumulatedHours: 0, rate: 500 };
    db[employeeId].rate = parseFloat(rate);
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, newRate: db[employeeId].rate });
});

// POST /api/commit-hours — Фиксация одного сотрудника
app.post('/api/commit-hours', async (req, res) => {
    const { employeeId } = req.body;
    if (!employeeId) return res.status(400).json({ error: 'employeeId обязателен' });
    const today = await getTodayHours(employeeId);
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, accumulatedHours: 0 };
    const dateStr = new Date().toISOString().split('T')[0];
    if (db[employeeId].lastSyncDate !== dateStr) {
        db[employeeId].accumulatedHours = (db[employeeId].accumulatedHours || 0) + today;
        db[employeeId].lastSyncDate = dateStr;
        console.log(`Зафиксировано: user ${employeeId} +${today.toFixed(2)} ч.`);
    }
    writeDB(db);
    res.json({ success: true, accumulatedHours: db[employeeId].accumulatedHours, addedHours: today });
});

// POST /api/commit-all — Массовая фиксация
app.post('/api/commit-all', async (req, res) => {
    const users = await getActiveUsers();
    if (!users?.length) return res.status(500).json({ error: 'Не удалось получить пользователей' });
    const db = readDB();
    const dateStr = new Date().toISOString().split('T')[0];
    let updated = 0;
    for (const user of users) {
        if (!db[user.ID]) db[user.ID] = { rate: 500, accumulatedHours: 0 };
        if (db[user.ID].lastSyncDate !== dateStr) {
            const h = await getTodayHours(user.ID);
            if (h > 0) {
                db[user.ID].accumulatedHours = (db[user.ID].accumulatedHours || 0) + h;
                db[user.ID].lastSyncDate = dateStr;
                updated++;
            }
        }
    }
    writeDB(db);
    console.log(`Массовая фиксация: обновлено ${updated} записей`);
    res.json({ success: true, updatedCount: updated });
});

// POST /api/adjust-hours — устаревший, можно удалить (теперь есть /api/adjust)
app.post('/api/adjust-hours', (req, res) => {
    const { employeeId, hours } = req.body;
    if (!employeeId || hours === undefined) return res.status(400).json({ error: 'employeeId и hours обязательны' });
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, accumulatedHours: 0 };
    db[employeeId].accumulatedHours = Math.max(0, parseFloat(hours));
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    res.json({ success: true, newAccumulatedHours: db[employeeId].accumulatedHours });
});

// Фронтенд
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Авто-сохранение в 23:30 МСК
cron.schedule('30 23 * * *', async () => {
    console.log('[CRON] Авто-сохранение часов...');
    try {
        await saveDailyHours();
        console.log('[CRON] Готово');
    } catch (e) {
        console.error('[CRON] Ошибка:', e.message);
    }
}, { timezone: 'Europe/Moscow' });

// Запуск
app.listen(PORT, () => {
    console.log(`b24-payroll v2.0 ready on port ${PORT}`);
    console.log(`Webhook: ${B24_WEBHOOK}`);
    console.log(`Database: ${DB_FILE}`);
});