require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const MCP_URL = process.env.MCP_URL || 'https://mcp-dev.bitrix24.tech/mcp';
const VIBE_API_KEY = process.env.VIBE_API_KEY;
const DB_FILE = path.join(__dirname, 'data.json');

app.use(express.json());
app.use(express.static('public'));

// === Работа с локальной БД (ставки и кэш часов) ===
const readDB = () => {
    if (!fs.existsSync(DB_FILE)) return {};
    try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8')); }
    catch (e) { return {}; }
};
const writeDB = (data) => fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');

// === Запрос к MCP-серверу ===
async function mcpCall(method, args = {}) {
    try {
        const resp = await axios.post(MCP_URL, {
            jsonrpc: "2.0",
            method: "call_tool",
            params: { name: method, arguments: args },
            id: Date.now()
        }, {
            headers: {
                'Authorization': `Bearer ${VIBE_API_KEY}`,
                'Content-Type': 'application/json'
            },
            timeout: 30000
        });
        const content = resp.data.result?.content?.[0]?.text;
        return content ? JSON.parse(content) : null;
    } catch (e) {
        console.error(`MCP ${method} error:`, e.message);
        return null;
    }
}

// === Получение активных сотрудников ===
async function getActiveUsers() {
    const result = await mcpCall('user.get', { 
        filter: { ACTIVE: 'Y', USER_TYPE: 'employee' },
        select: ['ID', 'NAME', 'LAST_NAME', 'EMAIL', 'WORK_POSITION', 'UF_DEPARTMENT']
    });
    return Array.isArray(result?.result) ? result.result : [];
}

// === Получение отработанных часов через timeman ===
async function getUserWorkedHours(userId) {
    // Пробуем timeman.status для текущего дня
    const status = await mcpCall('timeman.status', { userId });
    if (status?.result?.WORK_TIME) {
        // WORK_TIME в секундах → часы
        return Math.round(status.result.WORK_TIME / 3600);
    }
    
    // Если не получилось — пробуем отчеты за сегодня
    const today = new Date().toISOString().split('T')[0];
    const report = await mcpCall('timeman.timecontrol.reports.get', {
        filter: { USER_ID: userId, DATE_FROM: today, DATE_TO: today }
    });
    if (report?.result?.[0]?.WORK_TIME) {
        return Math.round(report.result[0].WORK_TIME / 3600);
    }
    
    // Фоллбэк: 0 часов
    return 0;
}

// === API: Получить всех сотрудников с данными ===
app.get('/api/employees', async (req, res) => {
    const localDB = readDB();
    const users = await getActiveUsers();
    
    if (!users || users.length === 0) {
        return res.status(500).json({ error: "Не удалось получить пользователей из Битрикс24" });
    }
    
    const employees = await Promise.all(users.map(async user => {
        const dbEntry = localDB[user.ID] || { rate: 500, totalHours: 0, lastSync: null };
        
        // Получаем часы за сегодня (можно кэшировать)
        const todayHours = await getUserWorkedHours(user.ID);
        const newTotalHours = dbEntry.totalHours + todayHours;
        
        return {
            id: user.ID,
            name: `${user.NAME || ''} ${user.LAST_NAME || ''}`.trim() || user.NAME || 'Без имени',
            email: user.EMAIL,
            position: user.WORK_POSITION,
            department: Array.isArray(user.UF_DEPARTMENT) ? user.UF_DEPARTMENT[0] : null,
            rate: dbEntry.rate,
            todayHours,
            totalHours: newTotalHours,
            totalMoney: newTotalHours * dbEntry.rate,
            lastSync: new Date().toISOString()
        };
    }));
    
    res.json(employees);
});

// === API: Обновить ставку сотрудника ===
app.post('/api/rate', (req, res) => {
    const { employeeId, rate } = req.body;
    if (!employeeId || rate === undefined) {
        return res.status(400).json({ error: "Требуется employeeId и rate" });
    }
    
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { totalHours: 0, rate: 500 };
    db[employeeId].rate = parseFloat(rate);
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    
    res.json({ success: true, newRate: db[employeeId].rate });
});

// === API: Добавить часы вручную (если timeman не доступен) ===
app.post('/api/add-hours', (req, res) => {
    const { employeeId, hours } = req.body;
    if (!employeeId || hours === undefined) {
        return res.status(400).json({ error: "Требуется employeeId и hours" });
    }
    
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, totalHours: 0 };
    db[employeeId].totalHours += parseFloat(hours);
    db[employeeId].lastUpdated = new Date().toISOString();
    writeDB(db);
    
    res.json({ success: true, newTotal: db[employeeId].totalHours });
});

// === API: Синхронизировать часы из timeman ===
app.post('/api/sync-hours', async (req, res) => {
    const { employeeId } = req.body;
    if (!employeeId) return res.status(400).json({ error: "Требуется employeeId" });
    
    const hours = await getUserWorkedHours(employeeId);
    const db = readDB();
    if (!db[employeeId]) db[employeeId] = { rate: 500, totalHours: 0 };
    db[employeeId].totalHours = hours; // Или +=, если нужно накапливать
    db[employeeId].lastSync = new Date().toISOString();
    writeDB(db);
    
    res.json({ success: true, syncedHours: hours });
});

// === Статический фронтенд ===
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`✅ b24-payroll v1.1.0 running on port ${PORT}`);
    console.log(`🔗 MCP: ${MCP_URL}`);
});