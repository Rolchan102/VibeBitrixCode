const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { calculateWorkedHours } = require('./utils/time_calc');

const B24_WEBHOOK = process.env.B24_WEBHOOK;

// === Утилиты ===
const readJSON = (file, fallback = {}) => {
    if (!fs.existsSync(file)) return fallback;
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return fallback; }
};
const writeJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
};

/**
 * Возвращает путь к файлу месяца: hours_may_2026.json
 */
function getMonthFile(monthStr) {
    const [year, mon] = monthStr.split('-');
    const monthNames = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
    const name = `${monthNames[parseInt(mon) - 1]}_${year}`;
    return path.join(__dirname, `hours_${name}.json`);
}

/**
 * Структура месячного файла:
 * {
 *   "meta": { "month": "2026-05", "employees": { "42": { "rate": 500, "bonus": 0 } } },
 *   "days": {
 *     "2026-05-01": { "42": { hours, duration_sec, status, name, ... } },
 *     ...
 *   }
 * }
 */
function readMonthData(monthStr) {
    const file = getMonthFile(monthStr);
    const data = readJSON(file, null);
    if (data) return data;
    // Новый месяц — инициализируем пустую структуру
    return { meta: { month: monthStr, employees: {} }, days: {} };
}

function writeMonthData(monthStr, data) {
    writeJSON(getMonthFile(monthStr), data);
}

// === Вызов Bitrix24 API ===
async function b24Call(method, params = {}) {
    const url = new URL(`${B24_WEBHOOK}${method}`);
    Object.entries(params).forEach(([key, value]) => {
        if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
            url.searchParams.append(key, JSON.stringify(value));
        } else {
            url.searchParams.append(key, String(value));
        }
    });
    const resp = await axios.get(url.toString(), { timeout: 30000 });
    return resp.data?.error ? null : resp.data;
}

// === Получение сотрудников ===
async function getActiveUsers() {
    let allUsers = [], start = 0;
    while (true) {
        const res = await b24Call('user.get', {
            ACTIVE: true, USER_TYPE: "employee", SORT: "ID", ORDER: "asc",
            SELECT: ["ID", "NAME", "LAST_NAME"], start
        });
        if (!res?.result?.length) break;
        allUsers = allUsers.concat(res.result);
        start = res.next ?? 0;
        if (res.next === undefined) break;
    }
    return allUsers;
}

// === Часы за сегодня ===
async function getTodayHours(userId) {
    try {
        const res = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        const calc = calculateWorkedHours(res?.result);
        return {
            hours: calc.hours,
            duration: calc.durationSec,
            status: calc.status
        };
    } catch (e) {
        console.error(`getTodayHours error (user ${userId}):`, e.message);
        return { hours: 0, duration: 0, status: 'error' };
    }
}

// === Основная функция: авто-сохранение часов за день ===
async function saveDailyHours() {
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = today.slice(0, 7);
    console.log(`[saveDailyHours] Начало сохранения за ${today}...`);

    const monthData = readMonthData(currentMonth);
    if (!monthData.days[today]) monthData.days[today] = {};

    const users = await getActiveUsers();
    if (!users.length) {
        console.error('[saveDailyHours] Не удалось получить сотрудников');
        return;
    }

    let saved = 0, skipped = 0, errors = 0;

    for (const user of users) {
        try {
            // Лимит запросов к Bitrix24 API (~2 req/sec)
            await new Promise(r => setTimeout(r, 600));

            const { hours, duration, status: b24Status } = await getTodayHours(user.ID);
            const hoursRounded = Math.round(hours * 100) / 100;

            // Пропускаем, если день уже зафиксирован вручную
            const existing = monthData.days[today]?.[user.ID];
            if (existing?.status === 'committed') {
                console.log(`[skip] User ${user.ID}: день ${today} уже зафиксирован вручную`);
                skipped++;
                continue;
            }

            // Сохраняем только если есть часы или день закрыт в Битрикс24
            if (hoursRounded >= 0.01 || b24Status === 'closed') {
                monthData.days[today][user.ID] = {
                    hours: hoursRounded,
                    duration_sec: Math.round(duration),
                    status: 'auto_saved',
                    name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                    autoSavedAt: new Date().toISOString(),
                    b24Status
                };
                saved++;
                console.log(`[save] User ${user.ID}: ${hoursRounded} ч (${b24Status})`);
            }

            // Инициализируем запись сотрудника в meta (ставка/премия) если нет
            if (!monthData.meta.employees[user.ID]) {
                // Пытаемся унаследовать ставку из предыдущего месяца
                const prevRate = getLastKnownRate(user.ID, currentMonth);
                monthData.meta.employees[user.ID] = {
                    name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                    rate: prevRate,
                    bonus: 0
                };
            }

        } catch (e) {
            errors++;
            console.error(`[error] User ${user.ID}: ${e.message}`);
        }
    }

    if (saved > 0 || errors > 0) {
        writeMonthData(currentMonth, monthData);
        console.log(`[saveDailyHours] Готово: +${saved} записей, пропущено: ${skipped}, ошибок: ${errors}`);
    } else {
        console.log(`[saveDailyHours] Нет новых данных для сохранения (пропущено: ${skipped})`);
    }
}

/**
 * Ищет последнюю известную ставку сотрудника из предыдущих месяцев.
 * Перебирает до 6 месяцев назад.
 */
function getLastKnownRate(userId, currentMonth, defaultRate = 500) {
    const [year, mon] = currentMonth.split('-').map(Number);
    for (let i = 1; i <= 6; i++) {
        let m = mon - i;
        let y = year;
        while (m <= 0) { m += 12; y--; }
        const prev = `${y}-${String(m).padStart(2, '0')}`;
        const data = readMonthData(prev);
        if (data?.meta?.employees?.[userId]?.rate !== undefined) {
            return data.meta.employees[userId].rate;
        }
    }
    return defaultRate;
}

module.exports = { saveDailyHours, readMonthData, writeMonthData, getMonthFile, getLastKnownRate };