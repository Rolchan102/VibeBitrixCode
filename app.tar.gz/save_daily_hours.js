const axios = require('axios');
const fs = require('fs');
const path = require('path');

const B24_WEBHOOK = process.env.B24_WEBHOOK;
const HISTORY_FILE = path.join(__dirname, 'all_hours.json');
const DB_FILE = path.join(__dirname, 'data.json');

// === Утилиты ===
const readJSON = (file, fallback = {}) => {
    if (!fs.existsSync(file)) return fallback;
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return fallback; }
};
const writeJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
};

// === Вызов Bitrix24 API ===
async function b24Call(method, params = {}) {
    const url = new URL(`${B24_WEBHOOK}${method}`);
    Object.entries(params).forEach(([key, value]) => {
        if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
            url.searchParams.append(key, JSON.stringify(value));
        } else {
            url.searchParams.append(key, String(value));
        }
    });
    const resp = await axios.get(url.toString(), { timeout: 30000 });
    return resp.data?.error ? null : resp.data;
}

// === Получение сотрудников ===
async function getActiveUsers() {
    let allUsers = [], start = 0;
    while (true) {
        const res = await b24Call('user.get', {
            ACTIVE: true, USER_TYPE: "employee", SORT: "ID", ORDER: "asc",
            SELECT: ["ID", "NAME", "LAST_NAME"], start
        });
        if (!res?.result?.length) break;
        allUsers = allUsers.concat(res.result);
        start = res.next ?? 0;
        if (res.next === undefined) break;
    }
    return allUsers;
}

// === Часы за сегодня ===
async function getTodayHours(userId) {
    try {
        const res = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        const ts = res?.result; if (!ts) return { hours: 0, duration: 0, status: 'unknown' };
        if (ts.DURATION > 0) return { hours: ts.DURATION / 3600, duration: ts.DURATION, status: ts.CURRENT_STATUS || 'unknown' };
        if (ts.TIME_START && !ts.TIME_FINISH) {
            const secs = Math.max(0, (Date.now() - new Date(ts.TIME_START).getTime()) / 1000);
            return { hours: secs / 3600, duration: secs, status: 'open' };
        }
        if (ts.TIME_START && ts.TIME_FINISH) {
            const secs = Math.max(0, (new Date(ts.TIME_FINISH) - new Date(ts.TIME_START)) / 1000);
            return { hours: secs / 3600, duration: secs, status: 'closed' };
        }
        return { hours: 0, duration: 0, status: 'unknown' };
    } catch { return { hours: 0, duration: 0, status: 'error' }; }
}

// === Основная функция ===
async function saveDailyHours() {
    const today = new Date().toISOString().split('T')[0];
    console.log(`Сохранение часов за ${today}...`);
    
    const history = readJSON(HISTORY_FILE, {});
    const db = readJSON(DB_FILE, {});
    
    // Защита от дублей
    if (history[today]) {
        console.log(`Данные за ${today} уже сохранены`);
        return;
    }
    
    const users = await getActiveUsers();
    if (!users.length) { console.error('Не удалось получить сотрудников'); return; }
    
    const todayData = {};
    let saved = 0;
    
    for (const user of users) {
        await new Promise(r => setTimeout(r, 600)); // лимит 2 req/sec
        const { hours, duration, status } = await getTodayHours(user.ID);
        const hoursRounded = Math.round(hours * 100) / 100;
        
        if (hoursRounded >= 0.01 || status === 'closed') {
            todayData[user.ID] = {
                hours: hoursRounded,
                duration_sec: Math.round(duration),
                status,
                name: `${user.NAME} ${user.LAST_NAME}`.trim()
            };
            saved++;
            // Обновляем накопленные часы
            if (!db[user.ID]) db[user.ID] = { rate: 500, accumulatedHours: 0 };
            db[user.ID].accumulatedHours = Math.round(((db[user.ID].accumulatedHours || 0) + hoursRounded) * 100) / 100;
            db[user.ID].lastSyncDate = today;
        }
    }
    
    if (saved > 0) {
        history[today] = todayData;
        writeJSON(HISTORY_FILE, history);
        writeJSON(DB_FILE, db);
        console.log(`Сохранено: ${saved} записей`);
    } else {
        console.log('Нет данных для сохранения');
    }
}

// Экспорт для использования в index.js
module.exports = { saveDailyHours };