const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { calculateWorkedHours } = require('./utils/time_calc');
const B24_WEBHOOK = process.env.B24_WEBHOOK;
const HISTORY_FILE = path.join(__dirname, 'all_hours.json');
const DB_FILE = path.join(__dirname, 'data.json');

// === Утилиты ===
const readJSON = (file, fallback = {}) => {
    if (!fs.existsSync(file)) return fallback;
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return fallback; }
};
const writeJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
};

// === Вызов Bitrix24 API ===
async function b24Call(method, params = {}) {
    const url = new URL(`${B24_WEBHOOK}${method}`);
    Object.entries(params).forEach(([key, value]) => {
        if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
            url.searchParams.append(key, JSON.stringify(value));
        } else {
            url.searchParams.append(key, String(value));
        }
    });
    const resp = await axios.get(url.toString(), { timeout: 30000 });
    return resp.data?.error ? null : resp.data;
}

// === Получение сотрудников ===
async function getActiveUsers() {
    let allUsers = [], start = 0;
    while (true) {
        const res = await b24Call('user.get', {
            ACTIVE: true, USER_TYPE: "employee", SORT: "ID", ORDER: "asc",
            SELECT: ["ID", "NAME", "LAST_NAME"], start
        });
        if (!res?.result?.length) break;
        allUsers = allUsers.concat(res.result);
        start = res.next ?? 0;
        if (res.next === undefined) break;
    }
    return allUsers;
}

// === Часы за сегодня ===
async function getTodayHours(userId) {
    try {
        const res = await b24Call('timeman.status', { USER_ID: parseInt(userId) });
        const calc = calculateWorkedHours(res?.result);
        return {
            hours: calc.hours,        // округлённые для хранения
            duration: calc.durationSec, // точные секунды
            status: calc.status
        };
    } catch (e) {
        console.error(`getTodayHours error (user ${userId}):`, e.message);
        return { hours: 0, duration: 0, status: 'error' };
    }
}

// === Основная функция: авто-сохранение часов за день ===
async function saveDailyHours() {
    const today = new Date().toISOString().split('T')[0];
    console.log(`[saveDailyHours] Начало сохранения за ${today}...`);
    
    const history = readJSON(HISTORY_FILE, {});
    const db = readJSON(DB_FILE, {});
    
    // Инициализируем дату в истории, если нет
    if (!history[today]) history[today] = {};
    
    const users = await getActiveUsers();
    if (!users.length) { 
        console.error('[saveDailyHours] Не удалось получить сотрудников'); 
        return; 
    }
    
    let saved = 0, skipped = 0, errors = 0;
    
    for (const user of users) {
        try {
            // 🔹 Лимит запросов к Bitrix24 API (2 req/sec)
            await new Promise(r => setTimeout(r, 600));
            
            const { hours, duration, status: b24Status } = await getTodayHours(user.ID);
            const hoursRounded = Math.round(hours * 100) / 100;
            
            // 🔹 Пропускаем, если день уже зафиксирован вручную (статус "committed")
            const existing = history[today]?.[user.ID];
            if (existing?.status === 'committed') {
                console.log(`[skip] User ${user.ID}: день ${today} уже зафиксирован вручную`);
                skipped++;
                continue;
            }
            
            // 🔹 Сохраняем только если есть часы или день закрыт в Битрикс24
            if (hoursRounded >= 0.01 || b24Status === 'closed') {
                history[today][user.ID] = {
                    hours: hoursRounded,
                    duration_sec: Math.round(duration),
                    status: 'auto_saved',  // ← отличие от ручного "committed"
                    name: `${user.NAME} ${user.LAST_NAME}`.trim(),
                    autoSavedAt: new Date().toISOString(),
                    b24Status  // ← сохраняем исходный статус из Битрикс24
                };
                saved++;
                console.log(`[save] User ${user.ID}: ${hoursRounded} ч (${b24Status})`);
            }
            
            // 🔹 Обновляем кэш в db.json (ставки, премии, accumulatedHours)
            if (!db[user.ID]) {
                db[user.ID] = { rate: 500, accumulatedHours: 0, bonus: 0 };
            }
            
            // Пересчитываем накопленные часы как сумму всех дней из истории за текущий месяц
            const currentMonth = today.slice(0, 7); // "2026-05"
            let monthTotal = 0;
            for (const [date, employees] of Object.entries(history)) {
                if (date.startsWith(currentMonth) && employees[user.ID]?.hours) {
                    monthTotal += employees[user.ID].hours;
                }
            }
            db[user.ID].accumulatedHours = Math.round(monthTotal * 100) / 100;
            db[user.ID].lastSyncDate = today;
            
        } catch (e) {
            errors++;
            console.error(`[error] User ${user.ID}: ${e.message}`);
        }
    }
    
    // 🔹 Сохраняем оба файла только если были изменения
    if (saved > 0 || errors > 0) {
        writeJSON(HISTORY_FILE, history);
        writeJSON(DB_FILE, db);
        console.log(`[saveDailyHours] Готово: +${saved} записей, пропущено: ${skipped}, ошибок: ${errors}`);
    } else {
        console.log(`[saveDailyHours] Нет новых данных для сохранения (пропущено: ${skipped})`);
    }
}

// Экспорт для использования в index.js
module.exports = { saveDailyHours };