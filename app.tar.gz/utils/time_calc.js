// utils/time_calc.js
/**
 * Универсальный расчёт отработанных часов из данных timeman.status
 * @param {Object} ts - Объект result из ответа timeman.status
 * @returns {Object} { hours, hoursRaw, durationSec, status, hasData }
 */
function calculateWorkedHours(ts) {
    const defaultResult = {
        hours: 0,
        hoursRaw: 0,
        durationSec: 0,
        status: 'unknown',
        hasData: false
    };

    if (!ts) return defaultResult;

    // === Случай 1: День закрыт (CLOSED) ===
    if (ts.STATUS === 'CLOSED' && ts.TIME_START && ts.TIME_FINISH) {
        const start = new Date(ts.TIME_START).getTime();
        const finish = new Date(ts.TIME_FINISH).getTime();
        const durationSec = Math.max(0, (finish - start) / 1000);
        return {
            hours: Math.round((durationSec / 3600) * 100) / 100,
            hoursRaw: durationSec / 3600,
            durationSec,
            status: 'closed',
            hasData: true
        };
    }

    // === Случай 2: Есть готовый DURATION ===
    if (ts.DURATION !== undefined && ts.DURATION !== null) {
        let durationSec = 0;

        if (typeof ts.DURATION === 'number') {
            durationSec = ts.DURATION;
        } else if (typeof ts.DURATION === 'string') {
            // Парсим строку "08:30:15" → секунды
            const parts = ts.DURATION.split(':').map(Number);
            if (parts.some(isNaN)) return defaultResult;
            durationSec = parts[0] * 3600 + parts[1] * 60 + (parts[2] || 0);
        } else {
            return defaultResult;
        }

        // Добавляем перерывы (TIME_LEAKS), если есть
        if (ts.TIME_LEAKS && typeof ts.TIME_LEAKS === 'string') {
            const leakParts = ts.TIME_LEAKS.split(':').map(Number);
            if (!leakParts.some(isNaN)) {
                const leakSec = leakParts[0] * 3600 + leakParts[1] * 60 + (leakParts[2] || 0);
                durationSec += leakSec;
            }
        }

        return {
            hours: Math.round((durationSec / 3600) * 100) / 100,
            hoursRaw: durationSec / 3600,
            durationSec,
            status: ts.CURRENT_STATUS || 'closed',
            hasData: true
        };
    }

    // === Случай 3: День ещё открыт (работает сейчас) ===
    if (ts.TIME_START && !ts.TIME_FINISH) {
        const start = new Date(ts.TIME_START).getTime();
        const durationSec = Math.max(0, (Date.now() - start) / 1000);
        return {
            hours: Math.round((durationSec / 3600) * 100) / 100,
            hoursRaw: durationSec / 3600,
            durationSec,
            status: 'open',
            hasData: true
        };
    }

    // === Нет данных ===
    return defaultResult;
}

/**
 * Быстрый геттер только для часов (для совместимости со старым кодом)
 * @param {Object} ts - Объект result из timeman.status
 * @returns {number} Часы, округлённые до 2 знаков
 */
function getHoursOnly(ts) {
    return calculateWorkedHours(ts).hours;
}

module.exports = { calculateWorkedHours, getHoursOnly };